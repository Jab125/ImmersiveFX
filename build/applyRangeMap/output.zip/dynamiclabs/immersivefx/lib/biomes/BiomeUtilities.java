/*
 * Dynamic Surroundings
 * Copyright (C) 2020  OreCruncher
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>
 */

package dynamiclabs.immersivefx.lib.biomes;

import com.google.common.collect.ImmutableSet;
import dynamiclabs.immersivefx.lib.GameUtils;
import dynamiclabs.immersivefx.lib.Localization;
import dynamiclabs.immersivefx.lib.gui.Color;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RegistryKey;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeRegistry;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.common.BiomeDictionary;
import net.minecraftforge.registries.ForgeRegistries;
import dynamiclabs.immersivefx.environs.Environs;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Collection;
import java.util.Set;

@OnlyIn(Dist.CLIENT)
public class BiomeUtilities {
    private BiomeUtilities() {

    }

    private static final Color NO_COLOR = new Color(1F, 1F, 1F);

    @Nonnull
    public static String getBiomeName(@Nonnull final Biome biome) {
        ResourceLocation loc = biome.getRegistryName();
        if (loc == null) {
            final Biome forgeBiome = getClientBiome(biome);
            if (forgeBiome != null)
                loc = forgeBiome.getRegistryName();
        }
        if (loc == null)
            return "UNKNOWN";
        final String fmt = String.format("biome.%s.%s", loc.func_110624_b(), loc.func_110623_a());
        return Localization.load(fmt);
    }

    // ===================================
    //
    // Miscellaneous Support Functions
    //
    // ===================================
    @Nonnull
    public static Collection<BiomeDictionary.Type> getBiomeTypes() {
        return BiomeDictionary.Type.getAll();
    }

    @Nonnull
    public static Color getColorForLiquid(@Nonnull final IBlockReader world, @Nonnull final BlockPos pos) {
        final FluidState fluidState = world.func_204610_c(pos);

        if (fluidState.func_206888_e())
            return NO_COLOR;

        // If the fluid is water, need to check the biome for coloration
        final Fluid fluid = fluidState.func_206886_c();
        if (fluid.func_207185_a(FluidTags.field_206959_a)) {
            final Biome biome = BiomeUtilities.getClientBiome(pos);
            if (biome != null)
                return new Color(biome.func_185361_o());
        }
        return new Color(fluid.getAttributes().getColor());
    }

    @Nonnull
    public static Set<BiomeDictionary.Type> getBiomeTypes(@Nonnull final Biome biome) {
        try {
            ResourceLocation loc = biome.getRegistryName();
            if (loc == null) {
                final Biome forgeBiome = getClientBiome(biome);
                if (forgeBiome != null)
                    loc = forgeBiome.getRegistryName();
            }
            if (loc != null) {
                RegistryKey<Biome> key = RegistryKey.func_240903_a_(Registry.field_239720_u_, loc);
                return BiomeDictionary.getTypes(key);
            }
        } catch (@Nonnull final Throwable t) {
            final String name = biome.toString(); //biome.getDisplayName().getFormattedText();
            Environs.LOGGER.warn("Unable to get biome type data for biome '%s'", name);
        }
        return ImmutableSet.of();
    }

    @Nullable
    public static Biome getClientBiome(@Nonnull final BlockPos pos) {
        final ClientWorld world = GameUtils.getWorld();
        if (world == null)
            return BiomeRegistry.field_244201_b;
        final Biome biome = world.func_226691_t_(pos);
        return getClientBiome(biome);
    }

    @Nullable
    public static Biome getClientBiome(@Nonnull final Biome biome) {
        final ClientWorld world = GameUtils.getWorld();
        if (world == null)
            return BiomeRegistry.field_244201_b;
        ResourceLocation loc = world.func_241828_r().func_243612_b(Registry.field_239720_u_).func_177774_c(biome);
        if (loc == null)
            return BiomeRegistry.field_244201_b;
        final Biome result = ForgeRegistries.BIOMES.getValue(loc);
        if (result == null)
            return BiomeRegistry.field_244201_b;
        return result;
    }
}
