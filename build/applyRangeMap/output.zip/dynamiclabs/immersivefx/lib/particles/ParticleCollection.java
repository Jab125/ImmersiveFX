/*
 * Dynamic Surroundings
 * Copyright (C) 2020  OreCruncher
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>
 */

package dynamiclabs.immersivefx.lib.particles;

import com.mojang.blaze3d.vertex.IVertexBuilder;
import dynamiclabs.immersivefx.lib.GameUtils;
import dynamiclabs.immersivefx.lib.TickCounter;
import dynamiclabs.immersivefx.lib.math.LoggingTimerEMA;
import dynamiclabs.immersivefx.lib.math.TimerEMA;
import net.minecraft.client.particle.IParticleRenderType;
import net.minecraft.client.renderer.ActiveRenderInfo;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import dynamiclabs.immersivefx.lib.collections.ObjectArray;

import javax.annotation.Nonnull;
import java.util.function.Predicate;

@OnlyIn(Dist.CLIENT)
final class ParticleCollection extends BaseParticle {

    public static final ICollectionFactory FACTORY = ParticleCollection::new;
    protected static final int MAX_PARTICLES = 4000;
    protected static final int ALLOCATION_SIZE = 128;
    protected static final int TICK_GRACE = 2;
    /**
     * Predicate used to update a mote and return whether it is dead or not.
     */
    private static final Predicate<IParticleMote> UPDATE_REMOVE = mote -> !mote.tick();

    protected final LoggingTimerEMA render;
    protected final LoggingTimerEMA tick;
    protected final ObjectArray<IParticleMote> myParticles = new ObjectArray<>(ALLOCATION_SIZE);
    protected final IParticleRenderType renderType;
    protected long lastTickUpdate;

    ParticleCollection(@Nonnull final String name, @Nonnull final World world, @Nonnull final IParticleRenderType renderType) {
        super(world, 0, 0, 0);

        this.field_190017_n = false;
        this.renderType = renderType;
        this.render = new LoggingTimerEMA("Render " + name);
        this.tick = new LoggingTimerEMA("Tick " + name);
        this.lastTickUpdate = TickCounter.getTickCount();
    }

    public boolean canFit() {
        return this.myParticles.size() < MAX_PARTICLES;
    }

    public void addParticle(@Nonnull final IParticleMote mote) {
        if (canFit()) {
            this.myParticles.add(mote);
        }
    }

    public int size() {
        return this.myParticles.size();
    }

    @Nonnull
    public TimerEMA getRenderTimer() {
        return this.render;
    }

    @Nonnull
    public TimerEMA getTickTimer() {
        return this.tick;
    }

    public boolean shouldDie() {
        final boolean timeout = (TickCounter.getTickCount() - this.lastTickUpdate) > TICK_GRACE;
        return timeout || size() == 0 || this.field_187122_b != GameUtils.getWorld();
    }

    @Override
    public void func_189213_a() {
        this.tick.begin();
        if (func_187113_k()) {
            this.lastTickUpdate = TickCounter.getTickCount();
            this.myParticles.removeIf(UPDATE_REMOVE);
            if (shouldDie()) {
                func_187112_i();
            }
        }
        this.tick.end();
    }

    @Override
    public boolean shouldCull() {
        return false;
    }

    @Override
    public void func_225606_a_(@Nonnull final IVertexBuilder buffer, @Nonnull final ActiveRenderInfo renderInfo, final float partialTicks) {
        this.render.begin();
        for (final IParticleMote mote : this.myParticles)
            if (FrustumHelper.isLocationInFrustum(mote.getPosition()))
                mote.renderParticle(buffer, renderInfo, partialTicks);
        this.render.end();
    }

    @Override
    @Nonnull
    public IParticleRenderType func_217558_b() {
        return this.renderType;
    }

    /**
     * Factory interface for creating particle collection instances. Used by the
     * ParticleCollections manager.
     */
    public interface ICollectionFactory {
        ParticleCollection create(@Nonnull final String name, @Nonnull final World world, @Nonnull final IParticleRenderType renderType);
    }

}