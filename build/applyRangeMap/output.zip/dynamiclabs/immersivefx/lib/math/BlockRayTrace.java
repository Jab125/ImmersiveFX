/*
 * Dynamic Surroundings: Sound Control
 * Copyright (C) 2019  OreCruncher
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>
 */

package dynamiclabs.immersivefx.lib.math;

import net.minecraft.block.BlockState;
import net.minecraft.fluid.FluidState;
import net.minecraft.util.Direction;
import net.minecraft.util.math.*;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.IBlockReader;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

/**
 * Block ray trace and context rolled into one!  With some optimizations specific to blocks.  These routines are
 * based on what the Minecraft raytrace algorithms do.  Pretty standard voxel based ray trace.
 */
public class BlockRayTrace {

    private static final double NUDGE = -1.0E-7D;

    final IBlockReader world;
    final RayTraceContext.BlockMode blockMode;
    final RayTraceContext.FluidMode fluidMode;
    final ISelectionContext selectionCtx;

    // Can be changed dynamically to avoid recreating contexts
    Vector3d start;
    Vector3d end;

    public BlockRayTrace(@Nonnull final IBlockReader world, @Nonnull final RayTraceContext.BlockMode bm, @Nonnull final RayTraceContext.FluidMode fm) {
        this(world, Vector3d.field_186680_a, Vector3d.field_186680_a, bm, fm);
    }

    public BlockRayTrace(@Nonnull final IBlockReader world, @Nonnull final Vector3d start, @Nonnull final Vector3d end, @Nonnull final RayTraceContext.BlockMode bm, @Nonnull final RayTraceContext.FluidMode fm) {
        this.world = world;
        this.start = start;
        this.end = end;
        this.blockMode = bm;
        this.fluidMode = fm;
        this.selectionCtx = ISelectionContext.func_216377_a();
    }

    @Nonnull
    public BlockRayTraceResult trace() {
        return traceLoop();
    }

    @Nonnull
    public BlockRayTraceResult trace(@Nonnull final Vector3d start, @Nonnull final Vector3d end) {
        this.start = start;
        this.end = end;
        return traceLoop();
    }

    @Nonnull
    private BlockRayTraceResult traceLoop() {
        if (this.start.equals(this.end)) {
            return miss();
        } else {

            final double lerpX = MathHelper.func_219803_d(NUDGE, this.start.field_72450_a, this.end.field_72450_a);
            final double lerpY = MathHelper.func_219803_d(NUDGE, this.start.field_72448_b, this.end.field_72448_b);
            final double lerpZ = MathHelper.func_219803_d(NUDGE, this.start.field_72449_c, this.end.field_72449_c);

            int posX = MathHelper.func_76128_c(lerpX);
            int posY = MathHelper.func_76128_c(lerpY);
            int posZ = MathHelper.func_76128_c(lerpZ);

            // Do a quick check on the first block.  If there is a hit return
            // that result.  Else, traverse the line segment between start and end
            // points until a hit.
            BlockPos.Mutable mutablePos = new BlockPos.Mutable(posX, posY, posZ);
            BlockRayTraceResult traceResult = hitCheck(mutablePos);
            if (traceResult == null) {
                // No hit.  Do the calcs to traverse the line
                final double xLerp = MathHelper.func_219803_d(NUDGE, this.end.field_72450_a, this.start.field_72450_a);
                final double yLerp = MathHelper.func_219803_d(NUDGE, this.end.field_72448_b, this.start.field_72448_b);
                final double zLerp = MathHelper.func_219803_d(NUDGE, this.end.field_72449_c, this.start.field_72449_c);
                final double lenX = xLerp - lerpX;
                final double lenY = yLerp - lerpY;
                final double lenZ = zLerp - lerpZ;
                final int dirX = MathHelper.func_219802_k(lenX);
                final int dirY = MathHelper.func_219802_k(lenY);
                final int dirZ = MathHelper.func_219802_k(lenZ);
                final double deltaX = dirX == 0 ? Double.MAX_VALUE : (dirX / lenX);
                final double deltaY = dirY == 0 ? Double.MAX_VALUE : (dirY / lenY);
                final double deltaZ = dirZ == 0 ? Double.MAX_VALUE : (dirZ / lenZ);

                double X = deltaX * (dirX > 0 ? 1.0D - MathHelper.func_181162_h(lerpX) : MathHelper.func_181162_h(lerpX));
                double Y = deltaY * (dirY > 0 ? 1.0D - MathHelper.func_181162_h(lerpY) : MathHelper.func_181162_h(lerpY));
                double Z = deltaZ * (dirZ > 0 ? 1.0D - MathHelper.func_181162_h(lerpZ) : MathHelper.func_181162_h(lerpZ));

                // Main processing loop that traverses the line segment between start and end point.  This process
                // will continue until there is a miss or a block is hit.
                do {
                    // Reached the end of the line?
                    if (X > 1.0D && Y > 1.0D && Z > 1.0D) {
                        return miss();
                    }

                    // Delta the axis that needs to be advanced.
                    if (X < Y) {
                        if (X < Z) {
                            posX += dirX;
                            X += deltaX;
                        } else {
                            posZ += dirZ;
                            Z += deltaZ;
                        }
                    } else if (Y < Z) {
                        posY += dirY;
                        Y += deltaY;
                    } else {
                        posZ += dirZ;
                        Z += deltaZ;
                    }

                    // Check for a hit.  If null is returned loop back around.
                    traceResult = hitCheck(mutablePos.func_181079_c(posX, posY, posZ));
                } while (traceResult == null);

            }
            // Return whatever result we have
            return traceResult;
        }
    }

    @Nonnull
    private BlockRayTraceResult miss() {
        final Vector3d directionVec = this.start.func_178788_d(this.end);
        return BlockRayTraceResult.func_216352_a(this.end, Direction.func_210769_a(directionVec.field_72450_a, directionVec.field_72448_b, directionVec.field_72449_c), new BlockPos(this.end));
    }

    // Fast path an empty air block as much as possible.  For tracing this would be the most common block
    // encountered.  As an FYI the logic needs to consider both the solid and fluid aspects of a block since
    // Minecraft now has this notion of water logged.
    @Nullable
    private BlockRayTraceResult hitCheck(@Nonnull final BlockPos pos) {
        // Handle the block
        BlockRayTraceResult traceResult = null;
        final BlockState state = this.world.func_180495_p(pos);
        if (!state.isAir(this.world, pos)) {
            final VoxelShape voxelShape = this.blockMode.get(state, this.world, pos, this.selectionCtx);
            if (!voxelShape.func_197766_b())
                traceResult = this.world.func_217296_a(this.start, this.end, pos, voxelShape, state);
        }

        // Handle it's fluid state
        BlockRayTraceResult fluidTraceResult = null;
        final FluidState fluidState = state.func_204520_s();
        if (!fluidState.func_206888_e() && this.fluidMode.func_222248_a(fluidState)) {
            final VoxelShape voxelFluidShape = state.func_196954_c(this.world, pos);
            if (!voxelFluidShape.func_197766_b())
                fluidTraceResult = voxelFluidShape.func_212433_a(this.start, this.end, pos);
        }

        // No results for either
        if (traceResult == fluidTraceResult)
            return null;
        // No fluid result
        if (fluidTraceResult == null)
            return traceResult;
        // No block result
        if (traceResult == null)
            return fluidTraceResult;

        // Get the closest.  It is possible to encounter the water before the solid, like a fence post that is
        // water logged.
        final double blockDistance = this.start.func_72436_e(traceResult.func_216347_e());
        final double fluidDistance = this.start.func_72436_e(fluidTraceResult.func_216347_e());
        return blockDistance <= fluidDistance ? traceResult : fluidTraceResult;
    }
}
