/*
 * Dynamic Surroundings
 * Copyright (C) 2020  OreCruncher
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>
 */

package dynamiclabs.immersivefx.lib;

import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import net.minecraft.block.material.Material;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

@SuppressWarnings("unused")
public final class MaterialUtils {

    private static final Reference2ObjectOpenHashMap<Material, String> materialMap = new Reference2ObjectOpenHashMap<>();
    private static final Map<String, Material> materialMapInv = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);

    static {
        materialMap.defaultReturnValue("CUSTOM");

        materialMap.put(Material.field_151579_a, "AIR");
        materialMap.put(Material.field_189963_J, "STRUCTURE_VOID");
        materialMap.put(Material.field_151567_E, "PORTAL");
        materialMap.put(Material.field_151593_r, "CARPET");
        materialMap.put(Material.field_151585_k, "PLANTS");
        materialMap.put(Material.field_203243_f, "OCEAN_PLANT");
        materialMap.put(Material.field_151582_l, "TALL_PLANTS");
        materialMap.put(Material.field_242934_h, "NETHER_PLANTS");
        materialMap.put(Material.field_204868_h, "SEA_GRASS");
        materialMap.put(Material.field_151586_h, "WATER");
        materialMap.put(Material.field_203244_i, "BUBBLE_COLUMN");
        materialMap.put(Material.field_151587_i, "LAVA");
        materialMap.put(Material.field_151597_y, "SNOW");
        materialMap.put(Material.field_151581_o, "FIRE");
        materialMap.put(Material.field_151594_q, "MISCELLANEOUS");
        materialMap.put(Material.field_151569_G, "WEB");
        materialMap.put(Material.field_151591_t, "REDSTONE_LIGHT");
        materialMap.put(Material.field_151571_B, "CLAY");
        materialMap.put(Material.field_151578_c, "EARTH");
        materialMap.put(Material.field_151577_b, "ORGANIC");
        materialMap.put(Material.field_151598_x, "PACKED_ICE");
        materialMap.put(Material.field_151595_p, "SAND");
        materialMap.put(Material.field_151583_m, "SPONGE");
        materialMap.put(Material.field_215711_w, "SHULKER");
        materialMap.put(Material.field_151575_d, "WOOD");
        materialMap.put(Material.field_237214_y_, "NETHER_WOOD");
        materialMap.put(Material.field_215712_y, "BAMBOO_SAPLING");
        materialMap.put(Material.field_215713_z, "BAMBOO");
        materialMap.put(Material.field_151580_n, "WOOL");
        materialMap.put(Material.field_151590_u, "TNT");
        materialMap.put(Material.field_151584_j, "LEAVES");
        materialMap.put(Material.field_151592_s, "GLASS");
        materialMap.put(Material.field_151588_w, "ICE");
        materialMap.put(Material.field_151570_A, "CACTUS");
        materialMap.put(Material.field_151576_e, "ROCK");
        materialMap.put(Material.field_151573_f, "IRON");
        materialMap.put(Material.field_151596_z, "SNOW_BLOCK");
        materialMap.put(Material.field_151574_g, "ANVIL");
        materialMap.put(Material.field_175972_I, "BARRIER");
        materialMap.put(Material.field_76233_E, "PISTON");
        materialMap.put(Material.field_151589_v, "CORAL");
        materialMap.put(Material.field_151572_C, "GOURD");
        materialMap.put(Material.field_151566_D, "DRAGON_EGG");
        materialMap.put(Material.field_151568_F, "CAKE");

        // Create the inverse map
        for (final Map.Entry<Material, String> kvp : materialMap.entrySet()) {
            materialMapInv.put(kvp.getValue(), kvp.getKey());
        }
    }

    private MaterialUtils() {

    }

    @Nonnull
    public static Set<Material> getMaterials() {
        return materialMap.keySet();
    }

    @Nullable
    public static Material getMaterial(@Nonnull final String name) {
        return materialMapInv.get(name);
    }

    @Nullable
    public static String getMaterialName(@Nonnull final Material mat) {
        return materialMap.get(mat);
    }
}
