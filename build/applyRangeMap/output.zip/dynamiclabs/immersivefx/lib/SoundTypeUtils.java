/*
 * Dynamic Surroundings
 * Copyright (C) 2020  OreCruncher
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>
 */

package dynamiclabs.immersivefx.lib;

import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import net.minecraft.block.SoundType;
import net.minecraft.util.SoundEvent;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Map;
import java.util.TreeMap;
import java.util.function.Consumer;

@SuppressWarnings("unused")
public final class SoundTypeUtils {

    private static final Reference2ObjectOpenHashMap<SoundType, String> soundTypeMap = new Reference2ObjectOpenHashMap<>();
    private static final Map<String, SoundType> soundTypeMapInv = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);

    static {
        soundTypeMap.defaultReturnValue("CUSTOM");

        soundTypeMap.put(SoundType.field_185848_a, "WOOD");
        soundTypeMap.put(SoundType.field_185849_b, "GROUND");
        soundTypeMap.put(SoundType.field_185850_c, "PLANT");
        soundTypeMap.put(SoundType.field_235600_d_, "LILY_PADS");
        soundTypeMap.put(SoundType.field_185851_d, "STONE");
        soundTypeMap.put(SoundType.field_185852_e, "METAL");
        soundTypeMap.put(SoundType.field_185853_f, "GLASS");
        soundTypeMap.put(SoundType.field_185854_g, "CLOTH");
        soundTypeMap.put(SoundType.field_185855_h, "SAND");
        soundTypeMap.put(SoundType.field_185856_i, "SNOW");
        soundTypeMap.put(SoundType.field_185857_j, "LADDER");
        soundTypeMap.put(SoundType.field_185858_k, "ANVIL");
        soundTypeMap.put(SoundType.field_185859_l, "SLIME");
        soundTypeMap.put(SoundType.field_226947_m_, "HONEY");
        soundTypeMap.put(SoundType.field_211382_m, "WET_GRASS");
        soundTypeMap.put(SoundType.field_211383_n, "CORAL");
        soundTypeMap.put(SoundType.field_222468_o, "BAMBOO");
        soundTypeMap.put(SoundType.field_222469_p, "BAMBOO_SAPLING");
        soundTypeMap.put(SoundType.field_222470_q, "SCAFFOLDING");
        soundTypeMap.put(SoundType.field_222471_r, "SWEET_BERRY_BUSH");
        soundTypeMap.put(SoundType.field_222472_s, "CROP");
        soundTypeMap.put(SoundType.field_222473_t, "STEM");
        soundTypeMap.put(SoundType.field_235601_w_, "VINE");
        soundTypeMap.put(SoundType.field_222474_u, "NETHER_WART");
        soundTypeMap.put(SoundType.field_222475_v, "LANTERN");
        soundTypeMap.put(SoundType.field_235602_z_, "HYPHAE");
        soundTypeMap.put(SoundType.field_235579_A_, "NYLIUM");
        soundTypeMap.put(SoundType.field_235580_B_, "FUNGUS");
        soundTypeMap.put(SoundType.field_235581_C_, "ROOT");
        soundTypeMap.put(SoundType.field_235582_D_, "SHROOMLIGHT");
        soundTypeMap.put(SoundType.field_235583_E_, "NETHER_VINE");
        soundTypeMap.put(SoundType.field_235584_F_, "NETHER_VINE_LOWER_PITCH");
        soundTypeMap.put(SoundType.field_235585_G_, "SOUL_SAND");
        soundTypeMap.put(SoundType.field_235586_H_, "SOUL_SOIL");
        soundTypeMap.put(SoundType.field_235587_I_, "BASALT");
        soundTypeMap.put(SoundType.field_235588_J_, "WART");
        soundTypeMap.put(SoundType.field_235589_K_, "NETHERRACK");
        soundTypeMap.put(SoundType.field_235590_L_, "NETHER_BRICK");
        soundTypeMap.put(SoundType.field_235591_M_, "NETHER_SPROUT");
        soundTypeMap.put(SoundType.field_235592_N_, "NETHER_ORE");
        soundTypeMap.put(SoundType.field_235593_O_, "BONE");
        soundTypeMap.put(SoundType.field_235594_P_, "NETHERITE");
        soundTypeMap.put(SoundType.field_235595_Q_, "ANCIENT_DEBRIS");
        soundTypeMap.put(SoundType.field_235596_R_, "LODESTONE");
        soundTypeMap.put(SoundType.field_235597_S_, "CHAIN");
        soundTypeMap.put(SoundType.field_235598_T_, "NETHER_GOLD");
        soundTypeMap.put(SoundType.field_235599_U_, "GILDED_BLACKSTONE");

        // Create the inverse map
        for (final Map.Entry<SoundType, String> kvp : soundTypeMap.entrySet()) {
            soundTypeMapInv.put(kvp.getValue(), kvp.getKey());
        }
    }

    private SoundTypeUtils() {

    }

    public static void forEach(@Nonnull final Consumer<SoundType> consumer) {
        for (final SoundType type : soundTypeMap.keySet())
            consumer.accept(type);
    }

    @Nullable
    public static SoundType getSoundType(@Nonnull final String name) {
        return soundTypeMapInv.get(name);
    }

    @Nullable
    public static String getSoundTypeName(@Nonnull final SoundType st) {
        return soundTypeMap.get(st);
    }

    public static boolean isStepSoundValid(@Nullable final SoundType st) {
        return st != null && isValid(st.func_185844_d());
    }

    public static boolean isValid(@Nonnull final SoundEvent se) {
        return se != null && se.func_187503_a() != null;
    }
}
