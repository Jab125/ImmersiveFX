/*
 * Dynamic Surroundings: Sound Control
 * Copyright (C) 2019  OreCruncher
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>
 */

package dynamiclabs.immersivefx.sndctrl.client;

import com.google.common.collect.ImmutableList;
import dynamiclabs.immersivefx.lib.GameUtils;
import dynamiclabs.immersivefx.lib.MaterialUtils;
import dynamiclabs.immersivefx.lib.TickCounter;
import dynamiclabs.immersivefx.lib.blockstate.BlockStateMatcher;
import dynamiclabs.immersivefx.lib.events.DiagnosticEvent;
import dynamiclabs.immersivefx.sndctrl.SoundControl;
import net.minecraft.block.BlockState;
import net.minecraft.block.SoundType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.nbt.NBTUtil;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.apache.commons.lang3.StringUtils;
import dynamiclabs.immersivefx.sndctrl.config.Config;
import dynamiclabs.immersivefx.sndctrl.events.BlockInspectionEvent;
import dynamiclabs.immersivefx.sndctrl.events.EntityInspectionEvent;
import dynamiclabs.immersivefx.sndctrl.library.AudioEffectLibrary;

import javax.annotation.Nonnull;
import java.util.List;
import java.util.stream.Collectors;

@Mod.EventBusSubscriber(modid = SoundControl.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class Inspector {

    private static final String TEXT_BLOCKSTATE = TextFormatting.DARK_PURPLE + "<BlockState>";
    private static final String TEXT_TAGS = TextFormatting.DARK_PURPLE + "<Tags>";

    private static List<String> diagnostics = ImmutableList.of();

    private Inspector() {

    }

    private static List<String> getTags(@Nonnull final BlockState state) {
        return state.func_177230_c().getTags().stream().map(t -> "#" + t.toString()).collect(Collectors.toList());
    }

    private static void gatherBlockText(final ItemStack stack, final List<String> text, final BlockState state,
                                        final BlockPos pos) {

        if (!stack.func_190926_b()) {
            text.add(TextFormatting.RED + stack.func_200301_q().getString());
            final String itemName = stack.func_77973_b().func_200296_o().getString();
            if (!StringUtils.isEmpty(itemName)) {
                text.add("ITEM: " + itemName);
                text.add(TextFormatting.DARK_AQUA + stack.func_77973_b().getClass().getName());
            }
        }

        if (state != null) {
            final BlockStateMatcher info = BlockStateMatcher.create(state);
            if (!info.isEmpty()) {
                text.add("BLOCK: " + info.toString());
                text.add(TextFormatting.DARK_AQUA + info.getBlock().getClass().getName());
                text.add("Material: " + MaterialUtils.getMaterialName(state.func_185904_a()));
                final SoundType st = state.func_215695_r();
                text.add("Step Sound: " + st.func_185844_d().getRegistryName().toString());
                text.add("Reflectivity: " + AudioEffectLibrary.getReflectivity(state));
                text.add("Occlusion: " + AudioEffectLibrary.getOcclusion(state));
                text.add(TEXT_BLOCKSTATE);
                final CompoundNBT nbt = NBTUtil.func_190009_a(state);
                text.add(nbt.toString());
                final List<String> tagNames = getTags(state);
                if (tagNames.size() > 0) {
                    text.add(TEXT_TAGS);
                    for (final String ore : tagNames)
                        text.add(TextFormatting.GOLD + ore);
                }
            }
        }

    }

    private static boolean isHolding() {
        final PlayerEntity player = GameUtils.getPlayer();
        if (player == null)
            return false;
        final ItemStack held = player.func_184586_b(Hand.MAIN_HAND);
        return !held.func_190926_b() && held.func_77973_b() == Items.field_151146_bM;
    }

    @SubscribeEvent
    public static void onClientTick(@Nonnull final TickEvent.ClientTickEvent event) {

        if (TickCounter.getTickCount() % 5 == 0) {

            diagnostics = ImmutableList.of();

            if (Config.CLIENT.logging.enableLogging.get() && isHolding()) {
                final World world = GameUtils.getWorld();
                if (GameUtils.getMC().field_147125_j != null) {
                    final EntityInspectionEvent evt = new EntityInspectionEvent(GameUtils.getMC().field_147125_j);
                    evt.data.add(TextFormatting.RED + "Entity " + evt.entity.toString());
                    MinecraftForge.EVENT_BUS.post(evt);
                    diagnostics = evt.data;
                } else {
                    final RayTraceResult current = GameUtils.getMC().field_71476_x;
                    if (current instanceof BlockRayTraceResult) {
                        final BlockRayTraceResult trace = (BlockRayTraceResult) current;
                        if (trace.func_216346_c() != RayTraceResult.Type.MISS) {

                            final BlockState state = world.func_180495_p(trace.func_216350_a());

                            if (!state.isAir(world, trace.func_216350_a())) {
                                final BlockInspectionEvent evt = new BlockInspectionEvent(trace, world, state, trace.func_216350_a());
                                MinecraftForge.EVENT_BUS.post(evt);
                                diagnostics = evt.data;
                            }
                        }
                    }
                }
            }
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onBlockInspectionEvent(@Nonnull final BlockInspectionEvent event) {
        final ItemStack stack = event.state.func_177230_c().getPickBlock(event.state, event.rayTrace, event.world, event.pos, GameUtils.getPlayer());
        gatherBlockText(stack, event.data, event.state, event.pos);
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onGatherText(@Nonnull final DiagnosticEvent event) {
        event.getLeft().addAll(diagnostics);
    }
}
