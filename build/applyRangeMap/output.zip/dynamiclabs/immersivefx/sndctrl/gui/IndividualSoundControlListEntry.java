/*
 * Dynamic Surroundings
 * Copyright (C) 2020  OreCruncher
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>
 */

package dynamiclabs.immersivefx.sndctrl.gui;

import com.mojang.blaze3d.matrix.MatrixStack;
import dynamiclabs.immersivefx.lib.GameUtils;
import dynamiclabs.immersivefx.lib.fml.ForgeUtils;
import dynamiclabs.immersivefx.lib.gui.ColorPalette;
import dynamiclabs.immersivefx.lib.gui.GuiHelpers;
import dynamiclabs.immersivefx.sndctrl.api.sound.Category;
import dynamiclabs.immersivefx.sndctrl.api.sound.ISoundCategory;
import dynamiclabs.immersivefx.sndctrl.api.sound.ISoundInstance;
import dynamiclabs.immersivefx.sndctrl.api.sound.SoundBuilder;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.IGuiEventListener;
import net.minecraft.client.gui.widget.Widget;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.client.gui.widget.list.AbstractOptionList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.fml.client.gui.widget.Slider;
import dynamiclabs.immersivefx.sndctrl.audio.AudioEngine;
import dynamiclabs.immersivefx.sndctrl.audio.SoundMetadata;
import dynamiclabs.immersivefx.sndctrl.library.IndividualSoundConfig;
import dynamiclabs.immersivefx.sndctrl.library.SoundLibrary;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

@OnlyIn(Dist.CLIENT)
public class IndividualSoundControlListEntry extends AbstractOptionList.Entry<IndividualSoundControlListEntry> implements Slider.ISlider, AutoCloseable {

    private static final int SLIDER_WIDTH = 100;
    private static final int BUTTON_WIDTH = 60;
    private static final int TOOLTIP_WIDTH = 300;
    private static final Button.IPressable NULL_PRESSABLE = (b) -> {};
    private static final ITextComponent CULL_ON = new TranslationTextComponent("sndctrl.text.soundconfig.cull");
    private static final ITextComponent CULL_OFF = new TranslationTextComponent("sndctrl.text.soundconfig.nocull");
    private static final ITextComponent BLOCK_ON = new TranslationTextComponent("sndctrl.text.soundconfig.block");
    private static final ITextComponent BLOCK_OFF = new TranslationTextComponent("sndctrl.text.soundconfig.noblock");
    private static final ITextComponent PLAY = new TranslationTextComponent("sndctrl.text.soundconfig.play");
    private static final ITextComponent STOP = new TranslationTextComponent("sndctrl.text.soundconfig.stop");
    private static final ITextComponent VANILLA_CREDIT = new TranslationTextComponent("sndctrl.text.tooltip.vanilla");
    private static final ITextComponent SLIDER_SUFFIX = new StringTextComponent("%");

    private static final TextFormatting[] CODING = new TextFormatting[] {TextFormatting.ITALIC, TextFormatting.AQUA};
    private static final Collection<ITextComponent> VOLUME_HELP = GuiHelpers.getTrimmedTextCollection("sndctrl.text.soundconfig.volume.help", TOOLTIP_WIDTH, CODING);
    private static final Collection<ITextComponent> PLAY_HELP = GuiHelpers.getTrimmedTextCollection("sndctrl.text.soundconfig.play.help", TOOLTIP_WIDTH, CODING);
    private static final Collection<ITextComponent> CULL_HELP = GuiHelpers.getTrimmedTextCollection("sndctrl.text.soundconfig.cull.help", TOOLTIP_WIDTH, CODING);
    private static final Collection<ITextComponent> BLOCK_HELP = GuiHelpers.getTrimmedTextCollection("sndctrl.text.soundconfig.block.help", TOOLTIP_WIDTH, CODING);

    private static final int CONTROL_SPACING = 3;

    private final IndividualSoundConfig config;
    private final Slider volume;
    private final Button blockButton;
    private final Button cullButton;
    private final Button playButton;

    private final List<Widget> children = new ArrayList<>();

    private List<ITextComponent> defaultTooltip;

    private ISoundInstance soundPlay;

    public IndividualSoundControlListEntry(@Nonnull final IndividualSoundConfig data, final boolean enablePlay) {
        this.config = data;

        this.volume = new Slider(
                0,
                0,
                SLIDER_WIDTH,
                0,
                StringTextComponent.field_240750_d_,
                SLIDER_SUFFIX,
                0,
                400,
                this.config.getVolumeScaleInt(),
                false,
                true,
                NULL_PRESSABLE,
                this);
        this.children.add(this.volume);

        this.blockButton = new Button(
                0,
                0,
                BUTTON_WIDTH,
                0,
                this.config.isBlocked() ? BLOCK_ON : BLOCK_OFF,
                this::toggleBlock);
        this.children.add(this.blockButton);

        this.cullButton = new Button(
                0,
                0,
                BUTTON_WIDTH,
                0,
                this.config.isCulled() ? CULL_ON : CULL_OFF,
                this::toggleCull);
        this.children.add(this.cullButton);

        this.playButton = new Button(
                0,
                0,
                BUTTON_WIDTH,
                0,
                PLAY,
                this::play) {

            @Override
            public void func_230988_a_(@Nonnull final SoundHandler ignore) {
                // Suppress the button click to avoid conflicting with the sound play
            }
        };

        this.playButton.field_230693_o_ = enablePlay;
        this.children.add(this.playButton);
    }

    @Override
    @Nonnull
    public List<? extends IGuiEventListener> func_231039_at__() {
        return this.children;
    }

    @Override
    public void func_230432_a_(@Nonnull final MatrixStack matrixStack, int index, int rowTop, int rowLeft, int rowWidth, int rowHeight, int mouseX, int mouseY, boolean mouseOver, float partialTick_) {
        final FontRenderer font = GameUtils.getMC().field_71466_p;
        final float labelY = rowTop + (rowHeight - font.field_78288_b) / 2F;
        final String text = this.config.getLocation().toString();
        font.func_238421_b_(matrixStack, text, (float) rowLeft, labelY, ColorPalette.WHITE.rgb());

        // Need to position the other controls appropriately
        int rightMargin = rowLeft + rowWidth;
        this.volume.field_230690_l_ = rightMargin - this.volume.func_230998_h_();
        this.volume.field_230691_m_ = rowTop;
        this.volume.setHeight(rowHeight);
        rightMargin -= this.volume.func_230998_h_() + CONTROL_SPACING;

        this.playButton.field_230690_l_ = rightMargin - this.playButton.func_230998_h_();
        this.playButton.field_230691_m_ = rowTop;
        this.playButton.setHeight(rowHeight);
        rightMargin -= this.playButton.func_230998_h_() + CONTROL_SPACING;

        this.blockButton.field_230690_l_ = rightMargin - this.blockButton.func_230998_h_();
        this.blockButton.field_230691_m_ = rowTop;
        this.blockButton.setHeight(rowHeight);
        rightMargin -= this.blockButton.func_230998_h_() + CONTROL_SPACING;

        this.cullButton.field_230690_l_ = rightMargin - this.cullButton.func_230998_h_();
        this.cullButton.setHeight(rowHeight);
        this.cullButton.field_230691_m_ = rowTop;

        for (final Widget w : this.children)
            w.func_230430_a_(matrixStack, mouseX, mouseY, partialTick_);
    }

    protected void toggleBlock(@Nonnull final Button button) {
        this.config.setIsBlocked(!this.config.isBlocked());
        button.func_238482_a_(this.config.isBlocked() ? BLOCK_ON : BLOCK_OFF);
    }

    protected void toggleCull(@Nonnull final Button button) {
        this.config.setIsCulled(!this.config.isCulled());
        button.func_238482_a_(this.config.isCulled() ? CULL_ON : CULL_OFF);
    }

    @Override
    public void onChangeSliderValue(@Nonnull final Slider slider) {
        this.config.setVolumeScaleInt(slider.getValueInt());
    }

    protected void play(@Nonnull final Button button) {
        if (this.soundPlay == null) {
            final Optional<SoundEvent> event = SoundLibrary.getSound(this.config.getLocation());
            event.ifPresent(se -> {
                this.soundPlay = SoundBuilder.builder(se, Category.CONFIG)
                        .setGlobal(true)
                        .setVolume(this.config.getVolumeScale())
                        .build();
                AudioEngine.play(this.soundPlay);
                this.playButton.func_238482_a_(STOP);
            });
        } else {
            AudioEngine.stop(this.soundPlay);
            this.soundPlay = null;
            this.playButton.func_238482_a_(PLAY);
        }
    }

    @Override
    public void close() {
        if (this.soundPlay != null) {
            AudioEngine.stop(this.soundPlay);
            this.soundPlay = null;
        }
    }

    public void tick() {
        if (this.soundPlay != null) {
            if (this.soundPlay.getState().isTerminal()) {
                this.soundPlay = null;
                this.playButton.func_238482_a_(PLAY);
            }
        }
    }

    @Nonnull
    protected List<ITextComponent> getToolTip(final int mouseX, final int mouseY) {
        if (this.defaultTooltip == null) {
            this.defaultTooltip = new ArrayList<>();
            final ResourceLocation loc = this.config.getLocation();

            final String modName = ForgeUtils.getModDisplayName(loc.func_110624_b());
            this.defaultTooltip.add(new StringTextComponent(TextFormatting.GOLD + modName));

            this.defaultTooltip.add(new StringTextComponent(TextFormatting.GRAY + loc.toString()));

            final SoundMetadata meta = SoundLibrary.getSoundMetadata(loc);
            final ITextComponent title = meta.getTitle();
            if (title != StringTextComponent.field_240750_d_)
                this.defaultTooltip.add(title);
            final ISoundCategory category = meta.getCategory();
            if (category != Category.NEUTRAL) {
                this.defaultTooltip.add(new TranslationTextComponent("sndctrl.text.tooltip.category").func_230529_a_(category.getTextComponent()));
            }

            if (modName.equals("Minecraft"))
                this.defaultTooltip.add(VANILLA_CREDIT);
            else
                this.defaultTooltip.addAll(meta.getCredits());
        }

        final List<ITextComponent> result = new ArrayList<>(this.defaultTooltip);

        if (this.volume.func_231047_b_(mouseX, mouseY)) {
            result.addAll(VOLUME_HELP);
        } else if (this.blockButton.func_231047_b_(mouseX, mouseY)) {
            result.addAll(BLOCK_HELP);
        } else if (this.cullButton.func_231047_b_(mouseX, mouseY)) {
            result.addAll(CULL_HELP);
        } else if (this.playButton.func_231047_b_(mouseX, mouseY)) {
            result.addAll(PLAY_HELP);
        }

        return result;
    }

    /**
     * Retrieves the updated data from the entry
     * @return Updated IndividualSoundControl data
     */
    @Nonnull
    public IndividualSoundConfig getData() {
        return this.config;
    }

}
