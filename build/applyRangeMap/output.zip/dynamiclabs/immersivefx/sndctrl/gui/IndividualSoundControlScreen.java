/*
 * Dynamic Surroundings
 * Copyright (C) 2020  OreCruncher
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>
 */

package dynamiclabs.immersivefx.sndctrl.gui;

import com.mojang.blaze3d.matrix.MatrixStack;
import dynamiclabs.immersivefx.lib.GameUtils;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.List;

@OnlyIn(Dist.CLIENT)
public class IndividualSoundControlScreen extends Screen {

    private static final int TOP_OFFSET = 10;
    private static final int BOTTOM_OFFSET = 15;
    private static final int HEADER_HEIGHT = 35;
    private static final int FOOTER_HEIGHT = 50;

    private static final int SEARCH_BAR_WIDTH = 200;
    private static final int SEARCH_BAR_HEIGHT = 20;

    private static final int SELECTION_HEIGHT_OFFSET = 5;
    private static final int SELECTION_WIDTH = 600;
    private static final int SELECTION_HEIGHT = 20;

    private static final int BUTTON_WIDTH = 60;
    private static final int BUTTON_HEIGHT = 20;
    private static final int BUTTON_SPACING = 10;
    private static final int CONTROL_WIDTH = BUTTON_WIDTH * 2 + BUTTON_SPACING;

    private static final int TOOLTIP_Y_OFFSET = 30;

    private static final ITextComponent SAVE = new TranslationTextComponent("gui.done");
    private static final ITextComponent CANCEL = new TranslationTextComponent("gui.cancel");

    protected final Screen parent;
    protected final boolean enablePlay;
    protected TextFieldWidget searchField;
    protected IndividualSoundControlList soundConfigList;
    protected Button save;
    protected Button cancel;

    protected IndividualSoundControlScreen(@Nullable final Screen parent, final boolean enablePlay) {
        super(new TranslationTextComponent("sndctrl.text.soundconfig.title"));
        this.parent = parent;
        this.enablePlay = enablePlay;
    }

    @Override
    protected void func_231160_c_() {

        GameUtils.getMC().field_195559_v.func_197967_a(true);

        // Setup search bar
        final int searchBarLeftMargin = (this.field_230708_k_ - SEARCH_BAR_WIDTH) / 2;
        final int searchBarY = TOP_OFFSET + HEADER_HEIGHT - SEARCH_BAR_HEIGHT;
        this.searchField = new TextFieldWidget(
                this.field_230712_o_,
                searchBarLeftMargin,
                searchBarY,
                SEARCH_BAR_WIDTH,
                SEARCH_BAR_HEIGHT,
                this.searchField,   // Copy existing data over
                StringTextComponent.field_240750_d_);

        this.searchField.func_212954_a((filter) -> this.soundConfigList.setSearchFilter(() -> filter, false));

        this.field_230705_e_.add(this.searchField);

        // Setup the list control
        final int topY = TOP_OFFSET + HEADER_HEIGHT + SELECTION_HEIGHT_OFFSET;
        final int bottomY = this.field_230709_l_ - BOTTOM_OFFSET - FOOTER_HEIGHT - SELECTION_HEIGHT_OFFSET;
        this.soundConfigList = new IndividualSoundControlList(
                this,
                GameUtils.getMC(),
                this.field_230708_k_,
                this.field_230709_l_,
                topY,
                bottomY,
                SELECTION_WIDTH,
                SELECTION_HEIGHT,
                this.enablePlay,
                () -> this.searchField.func_146179_b(),
                this.soundConfigList);

        this.field_230705_e_.add(this.soundConfigList);

        // Set the control buttons at the bottom
        final int controlMargin = (this.field_230708_k_ - CONTROL_WIDTH) / 2;
        final int controlHeight = this.field_230709_l_ - BOTTOM_OFFSET - BUTTON_HEIGHT;
        this.save = new Button(
                controlMargin,
                controlHeight,
                BUTTON_WIDTH,
                BUTTON_HEIGHT,
                SAVE,
                this::save);
        this.func_230480_a_(this.save);

        this.cancel = new Button(
                controlMargin + BUTTON_WIDTH + BUTTON_SPACING,
                controlHeight,
                BUTTON_WIDTH,
                BUTTON_HEIGHT,
                CANCEL,
                this::cancel);
        this.func_230480_a_(this.cancel);

        this.func_212928_a(this.searchField);
    }

    public void func_231023_e_() {
        this.searchField.func_146178_a();
        this.soundConfigList.tick();
    }

    public boolean func_231177_au__() {
        return true;
    }

    public boolean func_231046_a_(int keyCode, int scanCode, int modifiers) {
        return super.func_231046_a_(keyCode, scanCode, modifiers) || this.searchField.func_231046_a_(keyCode, scanCode, modifiers);
    }

    public void func_231175_as__() {
        GameUtils.getMC().func_147108_a(this.parent);
    }

    public boolean func_231042_a_(char codePoint, int modifiers) {
        return this.searchField.func_231042_a_(codePoint, modifiers);
    }

    public void func_230430_a_(@Nonnull final MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
        this.func_231165_f_(0);
        //this.renderBackground(matrixStack);
        this.soundConfigList.func_230430_a_(matrixStack, mouseX, mouseY, partialTicks);
        this.searchField.func_230430_a_(matrixStack, mouseX, mouseY, partialTicks);
        func_238472_a_(matrixStack, this.field_230712_o_, this.field_230704_d_, this.field_230708_k_ / 2, TOP_OFFSET, 16777215);
        super.func_230430_a_(matrixStack, mouseX, mouseY, partialTicks);

        if (this.soundConfigList.func_231047_b_(mouseX, mouseY)) {
            final IndividualSoundControlListEntry entry = this.soundConfigList.getEntryAt(mouseX, mouseY);
            if (entry != null) {
                final List<ITextComponent> toolTip = entry.getToolTip(mouseX, mouseY);
                this.renderWrappedToolTip(matrixStack, toolTip, mouseX, mouseY + TOOLTIP_Y_OFFSET, GameUtils.getMC().field_71466_p);
            }
        }
    }

    // Handlers

    protected void save(@Nonnull final Button button) {
        // Gather the changes and push to underlying routine for parsing and packaging
        this.soundConfigList.saveChanges();
        this.func_231164_f_();
        this.func_231175_as__();
    }

    protected void cancel(@Nonnull final Button button) {
        // Just discard - no processing
        this.func_231164_f_();
        this.func_231175_as__();
    }
}
