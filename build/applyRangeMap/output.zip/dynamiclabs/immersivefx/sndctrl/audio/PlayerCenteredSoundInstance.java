/*
 * Dynamic Surroundings
 * Copyright (C) 2020  OreCruncher
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>
 */

package dynamiclabs.immersivefx.sndctrl.audio;

import com.google.common.base.MoreObjects;
import dynamiclabs.immersivefx.sndctrl.api.sound.ISoundCategory;
import dynamiclabs.immersivefx.sndctrl.api.sound.ISoundInstance;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import javax.annotation.Nonnull;

import net.minecraft.client.audio.ISound.AttenuationType;

@OnlyIn(Dist.CLIENT)
public class PlayerCenteredSoundInstance extends WrappedSoundInstance {
    public PlayerCenteredSoundInstance(@Nonnull final ISoundInstance sound, @Nonnull final ISoundCategory category) {
        super(sound, category);
    }

    @Override
    public boolean func_217861_m() {
        return true;
    }

    @Override
    public AttenuationType func_147656_j() {
        return AttenuationType.NONE;
    }

    @Override
    public double func_147649_g() {
        return 0;
    }

    @Override
    public double func_147654_h() {
        return 0;
    }

    @Override
    public double func_147651_i() {
        return 0;
    }

    @Override
    @Nonnull
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .addValue(func_147650_b().toString())
                .addValue(getSoundCategory().toString())
                .addValue(getState().toString())
                .add("v", func_147653_e())
                .add("ev", SoundInstance.getEffectiveVolume(this))
                .add("p", func_147655_f())
                .toString();
    }
}
