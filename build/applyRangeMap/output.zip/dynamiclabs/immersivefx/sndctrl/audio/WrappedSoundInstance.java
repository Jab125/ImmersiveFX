/*
 * Dynamic Surroundings: Sound Control
 * Copyright (C) 2019  OreCruncher
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>
 */

package dynamiclabs.immersivefx.sndctrl.audio;

import dynamiclabs.immersivefx.sndctrl.api.sound.ISoundCategory;
import dynamiclabs.immersivefx.sndctrl.api.sound.ISoundInstance;
import net.minecraft.client.audio.ITickableSound;
import net.minecraft.client.audio.Sound;
import net.minecraft.client.audio.SoundEventAccessor;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Objects;

import net.minecraft.client.audio.ISound.AttenuationType;

/**
 * Base class for special sounds that aggregate the true sound being played.
 */
@OnlyIn(Dist.CLIENT)
public class WrappedSoundInstance implements ISoundInstance, ITickableSound {

    @Nonnull
    protected final ISoundInstance sound;
    @Nonnull
    protected final ISoundCategory category;

    public WrappedSoundInstance(@Nonnull final ISoundInstance sound, @Nonnull final ISoundCategory category) {
        this.sound = Objects.requireNonNull(sound);
        this.category = Objects.requireNonNull(category);
    }

    public WrappedSoundInstance(@Nonnull final ISoundInstance sound) {
        this.sound = Objects.requireNonNull(sound);
        this.category = sound.getSoundCategory();
    }

    @Override
    public boolean func_147667_k() {
        return getState().isTerminal();
    }

    @Override
    public void func_73660_a() {
        if (this.sound instanceof ITickableSound)
            ((ITickableSound) this.sound).func_73660_a();
    }

    @Nonnull
    @Override
    public SoundState getState() {
        return this.sound.getState();
    }

    @Override
    public void setState(@Nonnull SoundState state) {
        this.sound.setState(state);
    }

    @Override
    public int getPlayDelay() {
        return this.sound.getPlayDelay();
    }

    @Override
    public void setPlayDelay(int delay) {
        this.sound.setPlayDelay(delay);
    }

    @Nonnull
    @Override
    public ResourceLocation func_147650_b() {
        return this.sound.func_147650_b();
    }

    @Nullable
    @Override
    public SoundEventAccessor func_184366_a(SoundHandler handler) {
        return this.sound.func_184366_a(handler);
    }

    @Nonnull
    @Override
    public Sound func_184364_b() {
        return this.sound.func_184364_b();
    }

    @Nonnull
    @Override
    public SoundCategory func_184365_d() {
        return this.sound.func_184365_d();
    }

    @Nonnull
    @Override
    public ISoundCategory getSoundCategory() {
        return this.category;
    }

    @Override
    public boolean func_147657_c() {
        return this.sound.func_147657_c();
    }

    @Override
    public boolean func_217861_m() {
        return this.sound.func_217861_m();
    }

    @Override
    public int func_147652_d() {
        return this.sound.func_147652_d();
    }

    @Override
    public float func_147653_e() {
        return this.sound.func_147653_e();
    }

    @Override
    public float func_147655_f() {
        return this.sound.func_147655_f();
    }

    @Override
    public double func_147649_g() {
        return this.sound.func_147649_g();
    }

    @Override
    public double func_147654_h() {
        return this.sound.func_147654_h();
    }

    @Override
    public double func_147651_i() {
        return this.sound.func_147651_i();
    }

    @Nonnull
    @Override
    public AttenuationType func_147656_j() {
        return this.sound.func_147656_j();
    }
}
