/*
 * Dynamic Surroundings: Sound Control
 * Copyright (C) 2019  OreCruncher
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>
 */

package dynamiclabs.immersivefx.sndctrl.audio;

import com.google.common.base.MoreObjects;
import dynamiclabs.immersivefx.sndctrl.api.sound.ISoundInstance;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import javax.annotation.Nonnull;
import java.util.Objects;

/**
 * An EntitySoundInstance is one that is attached to an entity and will change position with that entity
 * every tick.  If the sound is a global sound (like music), it will stay around as long as it is repeatable
 * and the entity is alive.
 */
@OnlyIn(Dist.CLIENT)
public class EntitySoundInstance extends WrappedSoundInstance {

    @Nonnull
    private final Entity entity;

    private float x;
    private float y;
    private float z;

    public EntitySoundInstance(@Nonnull final Entity entity, @Nonnull final ISoundInstance sound) {
        super(sound);

        this.entity = Objects.requireNonNull(entity);

        updatePosition();
    }

    @Override
    public double func_147649_g() {
        return this.x;
    }

    @Override
    public double func_147654_h() {
        return this.y;
    }

    @Override
    public double func_147651_i() {
        return this.z;
    }

    @Override
    public boolean func_147667_k() {
        return !this.entity.func_70089_S() || super.func_147667_k();
    }

    @Override
    public int getPlayDelay() {
        return this.sound.getPlayDelay();
    }

    @Override
    public void setPlayDelay(final int delay) {
        this.sound.setPlayDelay(delay);
    }

    private void updatePosition() {
        final Vector3d box = this.entity.func_174813_aQ().func_189972_c();
        this.x = (float) box.field_72450_a;
        this.y = (float) box.field_72448_b;
        this.z = (float) box.field_72449_c;
    }

    @Override
    public void func_73660_a() {

        super.func_73660_a();

        // If we are not done playing, and the sound is not global, we
        // update the sound's position.
        if (!func_147667_k() && !func_217861_m()) {
            updatePosition();
        }
    }

    @Override
    @Nonnull
    public String toString() {
        //@formatter:off
        return MoreObjects.toStringHelper(this)
                .addValue(this.entity.toString())
                .addValue(func_147650_b().toString())
                .addValue(func_184365_d().toString())
                .addValue(func_147656_j().toString())
                .addValue(getState().toString())
                .add("v", func_147653_e())
                .add("ev", SoundInstance.getEffectiveVolume(this))
                .add("p", func_147655_f())
                .add("x", func_147649_g())
                .add("y", func_147654_h())
                .add("z", func_147651_i())
                .toString();
        //@formatter:on
    }
}
