/*
 * Dynamic Surroundings
 * Copyright (C) 2020  OreCruncher
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>
 */

package dynamiclabs.immersivefx.sndctrl.audio;

import com.google.common.base.MoreObjects;
import dynamiclabs.immersivefx.sndctrl.api.sound.ISoundCategory;
import dynamiclabs.immersivefx.sndctrl.api.sound.ISoundInstance;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import javax.annotation.Nonnull;

import net.minecraft.client.audio.ISound.AttenuationType;

@OnlyIn(Dist.CLIENT)
public class LoopingSoundInstance extends WrappedSoundInstance {

    private final Vector3d position;

    public LoopingSoundInstance(@Nonnull final ISoundInstance sound, @Nonnull final ISoundCategory category) {
        super(sound, category);
        this.position = null;
    }

    public LoopingSoundInstance(@Nonnull final ISoundInstance sound) {
        super(sound);
        this.position = null;
    }

    public LoopingSoundInstance(@Nonnull final ISoundInstance sound, @Nonnull final Vector3d position) {
        super(sound);
        this.position = position;
    }

    @Override
    public boolean func_147657_c() {
        return true;
    }

    @Override
    public int func_147652_d() {
        return 0;
    }

    @Override
    public int getPlayDelay() {
        return this.sound.getPlayDelay();
    }

    @Override
    public void setPlayDelay(final int delay) {
        this.sound.setPlayDelay(delay);
    }

    @Override
    public double func_147649_g() {
        return this.position != null ? (float) this.position.field_72450_a : super.func_147649_g();
    }

    @Override
    public double func_147654_h() {
        return this.position != null ? (float) this.position.field_72448_b : super.func_147654_h();
    }

    @Override
    public double func_147651_i() {
        return this.position != null ? (float) this.position.field_72449_c : super.func_147651_i();
    }

    @Override
    public AttenuationType func_147656_j() {
        return AttenuationType.LINEAR;
    }

    @Override
    @Nonnull
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .addValue(func_147650_b().toString())
                .addValue(getSoundCategory().toString())
                .addValue(getState().toString())
                .add("v", func_147653_e())
                .add("ev", SoundInstance.getEffectiveVolume(this))
                .add("p", func_147655_f())
                .add("x", func_147649_g())
                .add("y", func_147654_h())
                .add("z", func_147651_i())
                .toString();
    }

}
