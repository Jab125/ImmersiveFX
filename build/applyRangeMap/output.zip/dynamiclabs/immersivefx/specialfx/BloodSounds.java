package dynamiclabs.immersivefx.specialfx;

import dynamiclabs.immersivefx.dsurround.DynamicSurroundings;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;

import net.minecraft.world.World;
import net.minecraft.world.IWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.ResourceLocation;
import net.minecraft.item.SwordItem;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.AxeItem;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import java.util.Map;
import java.util.HashMap;



public class BloodSounds {
	@Mod.EventBusSubscriber
	private static class GlobalTrigger {
		@SubscribeEvent
		public static void onEntityAttacked(LivingAttackEvent event) {
			if (event != null && event.getEntity() != null) {
				Entity entity = event.getEntity();
				Entity sourceentity = event.getSource().func_76346_g();
				Entity imediatesourceentity = event.getSource().func_76364_f();
				double i = entity.func_226277_ct_();
				double j = entity.func_226278_cu_();
				double k = entity.func_226281_cx_();
				double amount = event.getAmount();
				World world = entity.field_70170_p;
				Map<String, Object> dependencies = new HashMap<>();
				dependencies.put("x", i);
				dependencies.put("y", j);
				dependencies.put("z", k);
				dependencies.put("amount", amount);
				dependencies.put("world", world);
				dependencies.put("entity", entity);
				dependencies.put("sourceentity", sourceentity);
				dependencies.put("imediatesourceentity", imediatesourceentity);
				dependencies.put("event", event);
				executeSplatter(dependencies);
			}
		}
	}

	public static void executeSplatter(Map<String, Object> dependencies) {

		IWorld world = (IWorld) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		Entity sourceentity = (Entity) dependencies.get("sourceentity");
		if (((sourceentity instanceof LivingEntity) ? ((LivingEntity) sourceentity).func_184614_ca() : ItemStack.field_190927_a)
				.func_77973_b() instanceof SwordItem
				|| ((sourceentity instanceof LivingEntity) ? ((LivingEntity) sourceentity).func_184614_ca() : ItemStack.field_190927_a)
				.func_77973_b() instanceof AxeItem
				|| ((sourceentity instanceof LivingEntity) ? ((LivingEntity) sourceentity).func_184614_ca() : ItemStack.field_190927_a)
				.func_77973_b() instanceof PickaxeItem) {
			if (world instanceof World && !world.func_201670_d()) {
				((World) world).func_184133_a(null, new BlockPos((int) x, (int) y, (int) z),
						(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("immersivefx:splatter")),
						SoundCategory.NEUTRAL, (float) 1, (float) 1);
			} else {
				((World) world).func_184134_a(x, y, z,
						(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("immersivefx:splatter")),
						SoundCategory.NEUTRAL, (float) 1, (float) 1, false);
			}
		}
	}
}
