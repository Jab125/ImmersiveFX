package dynamiclabs.immersivefx.specialfx;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;

import net.minecraft.world.World;
import net.minecraft.world.IWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.ResourceLocation;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.block.Blocks;
import net.minecraft.block.BlockState;

import java.util.Map;
import java.util.HashMap;

import dynamiclabs.immersivefx.dsurround.DynamicSurroundings;

public class RightClickSounds {
	@Mod.EventBusSubscriber
	private static class GlobalTrigger {
		@SubscribeEvent
		public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
			PlayerEntity entity = event.getPlayer();
			if (event.getHand() != entity.func_184600_cs()) {
				return;
			}
			double i = event.getPos().func_177958_n();
			double j = event.getPos().func_177956_o();
			double k = event.getPos().func_177952_p();
			IWorld world = event.getWorld();
			BlockState state = world.func_180495_p(event.getPos());
			Map<String, Object> dependencies = new HashMap<>();
			dependencies.put("x", i);
			dependencies.put("y", j);
			dependencies.put("z", k);
			dependencies.put("world", world);
			dependencies.put("entity", entity);
			dependencies.put("direction", event.getFace());
			dependencies.put("blockstate", state);
			dependencies.put("event", event);
			executeRightClickSounds(dependencies);
		}
	}

	public static void executeRightClickSounds(Map<String, Object> dependencies) {
		IWorld world = (IWorld) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		if ((world.func_180495_p(new BlockPos((int) x, (int) y, (int) z))).func_177230_c() == Blocks.field_150462_ai) {
			if (world instanceof World && !world.func_201670_d()) {
				((World) world)
						.func_184133_a(null, new BlockPos((int) x, (int) y, (int) z),
								(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS
										.getValue(new ResourceLocation("immersivefx:click_crafting_table")),
								SoundCategory.PLAYERS, (float) 1, (float) 1);
			} else {
				((World) world).func_184134_a(x, y, z,
						(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS
								.getValue(new ResourceLocation("immersivefx:click_crafting_table")),
						SoundCategory.PLAYERS, (float) 1, (float) 1, false);
			}
		}
		if ((world.func_180495_p(new BlockPos((int) x, (int) y, (int) z))).func_177230_c() == Blocks.field_150460_al) {
			if (world instanceof World && !world.func_201670_d()) {
				((World) world).func_184133_a(null, new BlockPos((int) x, (int) y, (int) z),
						(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("immersivefx:click_oven")),
						SoundCategory.PLAYERS, (float) 1, (float) 1);
			} else {
				((World) world).func_184134_a(x, y, z,
						(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("immersivefx:click_oven")),
						SoundCategory.PLAYERS, (float) 1, (float) 1, false);
			}
		}
		if ((world.func_180495_p(new BlockPos((int) x, (int) y, (int) z))).func_177230_c() == Blocks.field_222424_lM) {
			if (world instanceof World && !world.func_201670_d()) {
				((World) world).func_184133_a(null, new BlockPos((int) x, (int) y, (int) z),
						(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("immersivefx:click_oven")),
						SoundCategory.PLAYERS, (float) 1, (float) 1);
			} else {
				((World) world).func_184134_a(x, y, z,
						(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("immersivefx:click_oven")),
						SoundCategory.PLAYERS, (float) 1, (float) 1, false);
			}
		}
		if ((world.func_180495_p(new BlockPos((int) x, (int) y, (int) z))).func_177230_c() == Blocks.field_222423_lL) {
			if (world instanceof World && !world.func_201670_d()) {
				((World) world).func_184133_a(null, new BlockPos((int) x, (int) y, (int) z),
						(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("immersivefx:click_oven")),
						SoundCategory.PLAYERS, (float) 1, (float) 1);
			} else {
				((World) world).func_184134_a(x, y, z,
						(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("immersivefx:click_oven")),
						SoundCategory.PLAYERS, (float) 1, (float) 1, false);
			}
		}
		if ((world.func_180495_p(new BlockPos((int) x, (int) y, (int) z))).func_177230_c() == Blocks.field_150381_bn) {
			if (world instanceof World && !world.func_201670_d()) {
				((World) world).func_184133_a(null, new BlockPos((int) x, (int) y, (int) z),
						(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("immersivefx:click_loom")),
						SoundCategory.PLAYERS, (float) 1, (float) 1);
			} else {
				((World) world).func_184134_a(x, y, z,
						(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("immersivefx:click_loom")),
						SoundCategory.PLAYERS, (float) 1, (float) 1, false);
			}
		}
		if ((world.func_180495_p(new BlockPos((int) x, (int) y, (int) z))).func_177230_c() == Blocks.field_222421_lJ) {
			if (world instanceof World && !world.func_201670_d()) {
				((World) world).func_184133_a(null, new BlockPos((int) x, (int) y, (int) z),
						(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("immersivefx:click_loom")),
						SoundCategory.PLAYERS, (float) 1, (float) 1);
			} else {
				((World) world).func_184134_a(x, y, z,
						(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("immersivefx:click_loom")),
						SoundCategory.PLAYERS, (float) 1, (float) 1, false);
			}
		}
		if ((world.func_180495_p(new BlockPos((int) x, (int) y, (int) z))).func_177230_c() == Blocks.field_222425_lN) {
			if (world instanceof World && !world.func_201670_d()) {
				((World) world).func_184133_a(null, new BlockPos((int) x, (int) y, (int) z),
						(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("immersivefx:click_loom")),
						SoundCategory.PLAYERS, (float) 1, (float) 1);
			} else {
				((World) world).func_184134_a(x, y, z,
						(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("immersivefx:click_loom")),
						SoundCategory.PLAYERS, (float) 1, (float) 1, false);
			}
		}
		if ((world.func_180495_p(new BlockPos((int) x, (int) y, (int) z))).func_177230_c() == Blocks.field_222430_lS) {
			if (world instanceof World && !world.func_201670_d()) {
				((World) world).func_184133_a(null, new BlockPos((int) x, (int) y, (int) z),
						(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("immersivefx:click_grind_stone")),
						SoundCategory.PLAYERS, (float) 1, (float) 1);
			} else {
				((World) world).func_184134_a(x, y, z,
						(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("immersivefx:click_grind_stone")),
						SoundCategory.PLAYERS, (float) 1, (float) 1, false);
			}
		}
		if ((world.func_180495_p(new BlockPos((int) x, (int) y, (int) z))).func_177230_c() == Blocks.field_222427_lP) {
			if (world instanceof World && !world.func_201670_d()) {
				((World) world).func_184133_a(null, new BlockPos((int) x, (int) y, (int) z),
						(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("immersivefx:click_grind_stone")),
						SoundCategory.PLAYERS, (float) 1, (float) 1);
			} else {
				((World) world).func_184134_a(x, y, z,
						(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("immersivefx:click_grind_stone")),
						SoundCategory.PLAYERS, (float) 1, (float) 1, false);
			}
		}
		if ((world.func_180495_p(new BlockPos((int) x, (int) y, (int) z))).func_177230_c() == Blocks.field_222429_lR) {
			if (world instanceof World && !world.func_201670_d()) {
				((World) world).func_184133_a(null, new BlockPos((int) x, (int) y, (int) z),
						(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("immersivefx:click_upgrade")),
						SoundCategory.PLAYERS, (float) 1, (float) 1);
			} else {
				((World) world).func_184134_a(x, y, z,
						(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("immersivefx:click_upgrade")),
						SoundCategory.PLAYERS, (float) 1, (float) 1, false);
			}
		}
		if ((world.func_180495_p(new BlockPos((int) x, (int) y, (int) z))).func_177230_c() == Blocks.field_150467_bQ
				|| (world.func_180495_p(new BlockPos((int) x, (int) y, (int) z))).func_177230_c() == Blocks.field_196717_eY
				|| (world.func_180495_p(new BlockPos((int) x, (int) y, (int) z))).func_177230_c() == Blocks.field_196718_eZ) {
			if (world instanceof World && !world.func_201670_d()) {
				((World) world).func_184133_a(null, new BlockPos((int) x, (int) y, (int) z),
						(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("immersivefx:click_anvil")),
						SoundCategory.PLAYERS, (float) 1, (float) 1);
			} else {
				((World) world).func_184134_a(x, y, z,
						(net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("immersivefx:click_anvil")),
						SoundCategory.PLAYERS, (float) 1, (float) 1, false);
			}
		}
	}
}
