/*
 *  Dynamic Surroundings: Mob Effects
 *  Copyright (C) 2019  OreCruncher
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>
 */

package dynamiclabs.immersivefx.mobeffects.effects.particles;

import dynamiclabs.immersivefx.lib.GameUtils;
import net.minecraft.client.particle.IAnimatedSprite;
import net.minecraft.client.particle.IParticleRenderType;
import net.minecraft.client.particle.SpriteTexturedParticle;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import javax.annotation.Nonnull;

@OnlyIn(Dist.CLIENT)
public class BubbleBreathParticle  extends SpriteTexturedParticle {
    public BubbleBreathParticle(@Nonnull final LivingEntity entity, final boolean isDrowning) {
        super((ClientWorld) entity.func_130014_f_(), 0, 0, 0);

        // Reuse the bubble sheet
        final IAnimatedSprite spriteSet = GameUtils.getMC().field_71452_i.field_215242_i.get(ParticleTypes.field_197612_e.getRegistryName());
        this.func_217568_a(spriteSet);

        final Vector3d origin = ParticleUtils.getBreathOrigin(entity);
        final Vector3d trajectory = ParticleUtils.getLookTrajectory(entity);
        final double factor = isDrowning ? 0.02D : 0.005D;

        this.func_187109_b(origin.field_72450_a, origin.field_72448_b, origin.field_72449_c);
        this.field_187123_c = origin.field_72450_a;
        this.field_187124_d = origin.field_72448_b;
        this.field_187125_e = origin.field_72449_c;

        this.field_187129_i = trajectory.field_72450_a * factor;
        this.field_187130_j = trajectory.field_72448_b * 0.002D;
        this.field_187131_k = trajectory.field_72449_c * factor;

        this.field_70545_g = 0F;

        this.func_82338_g(0.2F);
        this.func_187115_a(0.02F, 0.02F);
        this.field_70544_f *= this.field_187136_p.nextFloat() * 0.6F + 0.2F;
        this.field_70544_f *= entity.func_70631_g_() ? 0.125F : 0.25F;
        this.field_70547_e = (int) (8.0D / (Math.random() * 0.8D + 0.2D));
    }

    public void func_189213_a() {
        this.field_187123_c = this.field_187126_f;
        this.field_187124_d = this.field_187127_g;
        this.field_187125_e = this.field_187128_h;
        if (this.field_70547_e-- <= 0) {
            this.func_187112_i();
        } else {
            this.field_187130_j += 0.002D;
            this.func_187110_a(this.field_187129_i, this.field_187130_j, this.field_187131_k);
            this.field_187129_i *= 0.8500000238418579D;
            this.field_187130_j *= 0.8500000238418579D;
            this.field_187131_k *= 0.8500000238418579D;
            if (!this.field_187122_b.func_204610_c(new BlockPos(this.field_187126_f, this.field_187127_g, this.field_187128_h)).func_206884_a(FluidTags.field_206959_a)) {
                this.func_187112_i();
            }
        }
    }

    public IParticleRenderType func_217558_b() {
        return IParticleRenderType.field_217603_c;
    }
}
