/*
 * Dynamic Surroundings
 * Copyright (C) 2020  OreCruncher
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>
 */

package dynamiclabs.immersivefx.mobeffects.footsteps;

import java.util.Random;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import dynamiclabs.immersivefx.lib.GameUtils;
import dynamiclabs.immersivefx.lib.TickCounter;
import dynamiclabs.immersivefx.lib.logging.IModLog;
import dynamiclabs.immersivefx.lib.math.MathStuff;
import dynamiclabs.immersivefx.lib.random.XorShiftRandom;
import dynamiclabs.immersivefx.mobeffects.MobEffects;
import dynamiclabs.immersivefx.mobeffects.config.Config;
import dynamiclabs.immersivefx.mobeffects.effects.particles.Collections;
import dynamiclabs.immersivefx.mobeffects.footsteps.accents.FootstepAccents;
import dynamiclabs.immersivefx.mobeffects.library.Constants;
import dynamiclabs.immersivefx.mobeffects.library.FootstepLibrary;
import net.minecraft.block.BlockState;
import net.minecraft.block.material.Material;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.tags.BlockTags;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.common.ForgeHooks;
import dynamiclabs.immersivefx.lib.collections.ObjectArray;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;
import dynamiclabs.immersivefx.sndctrl.api.acoustics.AcousticEvent;
import dynamiclabs.immersivefx.sndctrl.api.acoustics.IAcoustic;
import dynamiclabs.immersivefx.sndctrl.audio.acoustic.AcousticCompiler;

@OnlyIn(Dist.CLIENT)
public class Generator {

	protected static final IModLog LOGGER = MobEffects.LOGGER.createChild(Generator.class);

	public static final double PROBE_DEPTH = 1F / 16F;

	protected static final Random RANDOM = XorShiftRandom.current();
	protected static final int BRUSH_INTERVAL = 2;

	protected final Variator VAR;

	protected float dmwBase;
	protected float dwmYChange;
	protected double yPosition;

	protected double prevX = Double.MIN_VALUE;
	protected double prevY = Double.MIN_VALUE;
	protected double prevZ = Double.MIN_VALUE;

	protected boolean didJump;
	protected boolean isFlying;
	protected float fallDistance;

	protected float lastReference;
	protected boolean isImmobile;
	protected long timeImmobile;

	protected boolean isRightFoot;
	protected boolean isOnGround;
	protected boolean isOnLadder;
	protected boolean isInWater;
	protected boolean isSneaking;
	protected boolean isJumping;

	protected double xMovec;
	protected double zMovec;
	protected boolean scalStat;
	protected boolean stepThisFrame;

	protected BlockPos messyPos = BlockPos.field_177992_a;
	protected long brushesTime;

	// We calc our own because of inconsistencies with Minecraft
	protected double distanceWalkedOnStepModified;
	protected int pedometer;

	protected static final ObjectArray<IAcoustic> accents = new ObjectArray<>();

	public Generator(@Nonnull final Variator var) {
		this.VAR = var;
	}

	public int getPedometer() {
		return this.pedometer;
	}

	public void generateFootsteps(@Nonnull final LivingEntity entity) {

		// If an entity is a passenger or is sleeping then no footsteps to process
		if (entity.func_200601_bK() || entity.func_70608_bn())
			return;

		// No footstep or print effects for spectators
		if ((entity instanceof PlayerEntity) && entity.func_175149_v())
			return;

		// Clear starting state
		this.didJump = false;
		this.stepThisFrame = false;

		this.isOnGround = entity.func_233570_aj_();
		this.isOnLadder = isClimbing(entity);
		this.isInWater = entity.func_70090_H();
		this.isSneaking = entity.func_225608_bj_();
		this.isJumping = entity.field_70703_bu;

		simulateFootsteps(entity);
		simulateAirborne(entity);
		simulateBrushes(entity);

		if (this.stepThisFrame)
			this.pedometer++;

		if (Constants.FOOTSTEPS.getVolumeScale() > 0) {
			entity.field_70150_b = Float.MAX_VALUE;
		} else {
			final float dist = entity.field_70150_b;
			if (dist == Float.MAX_VALUE)
				entity.field_70150_b = 0;
		}
	}

	protected boolean isClimbing(@Nonnull final LivingEntity entity) {
		final World world = entity.func_130014_f_();
		final BlockPos blockPos = entity.func_233580_cy_();
		final BlockState blockState = world.func_180495_p(blockPos);
		return blockState.func_235714_a_(BlockTags.field_232878_as_) || ForgeHooks.isLivingOnLadder(blockState, world, blockPos, entity);

	}

	protected boolean stoppedImmobile(float reference) {
		final long current = TickCounter.getTickCount();
		final float diff = this.lastReference - reference;
		this.lastReference = reference;
		if (!this.isImmobile && diff == 0) {
			this.timeImmobile = current;
			this.isImmobile = true;
		} else if (this.isImmobile && diff != 0) {
			this.isImmobile = false;
			return current - this.timeImmobile > this.VAR.IMMOBILE_DURATION;
		}

		return false;
	}

	protected void updateWalkedOnStep(@Nonnull final LivingEntity entity) {

		float distance = 0F;

		// First time initialization
		if (Double.compare(this.prevX, Double.MIN_VALUE) == 0) {
			this.prevX = entity.func_226277_ct_();
			this.prevY = entity.func_226278_cu_();
			this.prevZ = entity.func_226281_cx_();
		} else {
			final double dX = entity.func_226277_ct_() - this.prevX;
			final double dY = entity.func_226278_cu_() - this.prevY;
			final double dZ = entity.func_226281_cx_() - this.prevZ;

			this.prevX = entity.func_226277_ct_();
			this.prevY = entity.func_226278_cu_();
			this.prevZ = entity.func_226281_cx_();

			// The amount of distance added is dependent on whether the player
			// is on the ground (moving x/z) or not (moving x/y/z)
			final double sqrt;
			if (entity.func_233570_aj_())
				sqrt = Math.sqrt(dX * dX + dZ * dZ);
			else
				sqrt = Math.sqrt(dX * dX + dY * dY + dZ * dZ);
			distance = (float) sqrt * 0.6F;
		}

		this.distanceWalkedOnStepModified += distance;
	}

	protected void simulateFootsteps(@Nonnull final LivingEntity entity) {

		updateWalkedOnStep(entity);

		final float distanceReference = (float) this.distanceWalkedOnStepModified;

		if (this.dmwBase > distanceReference) {
			this.dmwBase = 0;
			this.dwmYChange = 0;
		}

		final double movX = entity.func_213322_ci().field_72450_a;
		final double movZ = entity.func_213322_ci().field_72449_c;

		final double scal = movX * this.xMovec + movZ * this.zMovec;
		if (this.scalStat != scal < 0.001f) {
			this.scalStat = !this.scalStat;

			if (this.scalStat && this.VAR.PLAY_WANDER && !hasSpecialStoppingConditions(entity)) {
				playSinglefoot(entity, 0d, Constants.WANDER, this.isRightFoot);
			}
		}

		this.xMovec = movX;
		this.zMovec = movZ;

		if (this.isOnGround || this.isInWater || this.isOnLadder) {
			AcousticEvent event = null;

			float dwm = distanceReference - this.dmwBase;
			final boolean immobile = stoppedImmobile(distanceReference);
			if (immobile && !this.isOnLadder) {
				dwm = 0;
				this.dmwBase = distanceReference;
			}

			float distance = 0f;

			if (this.isOnLadder && !this.isOnGround) {
				distance = this.VAR.STRIDE_LADDER;
			} else if (!this.isInWater && MathStuff.abs(this.yPosition - entity.func_226278_cu_()) > 0.4d) {
				// This ensures this does not get recorded as landing, but as a
				// step
				if (this.yPosition < entity.func_226278_cu_()) { // Going upstairs
					distance = this.VAR.STRIDE_STAIR;
					event = speedDisambiguator(entity, Constants.UP, Constants.UP_RUN);
				} else if (!this.isSneaking) { // Going downstairs
					distance = -1f;
					event = speedDisambiguator(entity, Constants.DOWN, Constants.DOWN_RUN);
				}

				this.dwmYChange = distanceReference;

			} else {
				distance = this.VAR.STRIDE;
			}

			if (event == null) {
				event = speedDisambiguator(entity, Constants.WALK, Constants.RUN);
			}

			distance = reevaluateDistance(event, distance);

			if (dwm > distance) {
				produceStep(entity, event, 0F);
				stepped(entity, event);
				this.dmwBase = distanceReference;
			}
		}

		// This fixes an issue where the value is evaluated
		// while the player is between two steps in the air
		// while descending stairs
		if (this.isOnGround) {
			this.yPosition = entity.func_226278_cu_();
		}
	}

	protected void stepped(@Nonnull final LivingEntity entity, @Nonnull final AcousticEvent event) {
	}

	protected float reevaluateDistance(@Nonnull final AcousticEvent event, final float distance) {
		return distance;
	}

	protected void produceStep(@Nonnull final LivingEntity entity, @Nonnull final AcousticEvent event) {
		produceStep(entity, event, 0d);
	}

	protected void produceStep(@Nonnull final LivingEntity entity, @Nullable AcousticEvent event,
			final double verticalOffsetAsMinus) {
		if (!playSpecialStoppingConditions(entity)) {
			if (event == null)
				event = speedDisambiguator(entity, Constants.WALK, Constants.RUN);
			playSinglefoot(entity, verticalOffsetAsMinus, event, this.isRightFoot);
			this.isRightFoot = !this.isRightFoot;
		}

		this.stepThisFrame = true;
	}

	protected void simulateAirborne(@Nonnull final LivingEntity entity) {
		if ((this.isOnGround || this.isOnLadder) == this.isFlying) {
			this.isFlying = !this.isFlying;
			simulateJumpingLanding(entity);
		}

		if (this.isFlying)
			this.fallDistance = entity.field_70143_R;
	}

	protected void simulateJumpingLanding(@Nonnull final LivingEntity entity) {
		if (hasSpecialStoppingConditions(entity))
			return;

		if (this.isFlying && this.isJumping) {
			if (this.VAR.EVENT_ON_JUMP) {
				// If climbing stairs motion will be negative
				if (entity.func_213322_ci().field_72448_b > 0) {
					this.didJump = true;
					final double speed = entity.func_213322_ci().field_72450_a * entity.func_213322_ci().field_72450_a + entity.func_213322_ci().field_72449_c * entity.func_213322_ci().field_72449_c;

					if (speed < this.VAR.SPEED_TO_JUMP_AS_MULTIFOOT) {
						// STILL JUMP
						playMultifoot(entity, 0.4d, Constants.JUMP);
					} else {
						// RUNNING JUMP
						playSinglefoot(entity, 0.4d, Constants.JUMP, this.isRightFoot);
					}
				}
			}
		} else if (!this.isFlying && this.fallDistance > 0.01F) {
			if (this.fallDistance > this.VAR.LAND_HARD_DISTANCE_MIN) {
				playMultifoot(entity, 0d, Constants.LAND);
			} else if (!this.stepThisFrame && !this.isSneaking) {
				playSinglefoot(entity, 0d, speedDisambiguator(entity, Constants.CLIMB, Constants.CLIMB_RUN),
						this.isRightFoot);
				this.isRightFoot = !this.isRightFoot;
			}
		}
	}

	protected AcousticEvent speedDisambiguator(@Nonnull final LivingEntity entity, @Nonnull final AcousticEvent walk,
			@Nonnull final AcousticEvent run) {
		final double velocity = entity.func_213322_ci().field_72450_a * entity.func_213322_ci().field_72450_a + entity.func_213322_ci().field_72449_c * entity.func_213322_ci().field_72449_c;
		return velocity > this.VAR.SPEED_TO_RUN ? run : walk;
	}

	protected void simulateBrushes(@Nonnull final LivingEntity entity) {
		final long current = TickCounter.getTickCount();
		if (current >= this.brushesTime) {
			this.brushesTime = current + BRUSH_INTERVAL;
			if (proceedWithStep(entity) && (entity.func_213322_ci().field_72450_a != 0d || entity.func_213322_ci().field_72449_c != 0d)) {
				final int yy = MathStuff
						.floor(entity.func_226278_cu_() - PROBE_DEPTH - entity.func_70033_W() - (entity.func_233570_aj_() ? 0d : 0.25d));
				final BlockPos pos = new BlockPos(entity.func_226277_ct_(), yy, entity.func_226281_cx_());
				if (!this.messyPos.equals(pos)) {
					this.messyPos = pos;
					final Association assos = findAssociationMessyFoliage(entity, pos);
					if (assos != null)
						playAssociation(assos, Constants.WALK);
				}
			}
		}
	}

	protected boolean proceedWithStep(@Nonnull final LivingEntity entity) {
		return !this.isSneaking;
	}

	protected void playSinglefoot(@Nonnull final LivingEntity entity, final double verticalOffsetAsMinus,
			@Nonnull final AcousticEvent eventType, final boolean foot) {
		if (proceedWithStep(entity)) {
			final Association assos = findAssociation(entity, verticalOffsetAsMinus, foot);
			playAssociation(assos, eventType);
		}
	}

	protected void playMultifoot(@Nonnull final LivingEntity entity, final double verticalOffsetAsMinus,
			final AcousticEvent eventType) {

		if (proceedWithStep(entity)) {
			// STILL JUMP
			final Association leftFoot = findAssociation(entity, verticalOffsetAsMinus, false);
			final Association rightFoot = findAssociation(entity, verticalOffsetAsMinus, true);
			playAssociation(leftFoot, eventType);
			playAssociation(rightFoot, eventType);
		}
	}

	/**
	 * Play an association.
	 */
	protected void playAssociation(@Nullable final Association assoc, @Nonnull final AcousticEvent eventType) {
		if (assoc != null) {
			assoc.play(eventType);
		}
	}

	protected boolean shouldProducePrint(@Nonnull final LivingEntity entity) {
		return this.VAR.HAS_FOOTPRINT
				&& Config.CLIENT.footsteps.enableFootprintParticles.get()
				&& (this.isOnGround || !(this.isJumping || entity.field_70160_al))
				&& !entity.func_98034_c(GameUtils.getPlayer());
	}

	/**
	 * Find an association for an entities particular foot. This will fetch the
	 * player angle and use it as a basis to find out what block is below their feet
	 * (or which block is likely to be below their feet if the player is walking on
	 * the edge of a block when walking over non-emitting blocks like air or water).
	 */
	@Nullable
	protected Association findAssociation(@Nonnull final LivingEntity entity,
			final double verticalOffsetAsMinus, final boolean isRightFoot) {

		final float rotDegrees = MathStuff.wrapDegrees(entity.field_70177_z);
		final double rot = MathStuff.toRadians(rotDegrees);
		final float feetDistanceToCenter = isRightFoot ? -this.VAR.DISTANCE_TO_CENTER : this.VAR.DISTANCE_TO_CENTER;

		final double xx = entity.func_226277_ct_() + MathStuff.cos(rot) * feetDistanceToCenter;
		final double zz = entity.func_226281_cx_() + MathStuff.sin(rot) * feetDistanceToCenter;
		final double minY = entity.func_174813_aQ().field_72338_b;
		final FootStrikeLocation loc = new FootStrikeLocation(entity, xx, minY - PROBE_DEPTH - verticalOffsetAsMinus,
				zz);

		final AcousticResolver resolver = new AcousticResolver(entity.func_130014_f_(), loc,
				this.VAR.DISTANCE_TO_CENTER);

		final Association result = addFootstepAccent(entity, resolver.findAssociation());

		// It is possible that the association has no position, so it
		// needs to be checked.
		if (result != null && shouldProducePrint(entity)) {
			final Vector3d printPos = result.getStrikeLocation().footprintPosition();
			if (printPos != null) {
				FootprintStyle style = this.VAR.FOOTPRINT_STYLE;

				if (entity instanceof PlayerEntity) {
					style = Config.CLIENT.footsteps.playerFootprintStyle.get();
				}

				final Footprint print = Footprint.produce(
						style, entity, printPos, rotDegrees,
						this.VAR.FOOTPRINT_SCALE,
						isRightFoot);

				final Vector3d stepLocation = print.getStepLocation();
				final World world = print.getEntity().func_130014_f_();
				Collections.addFootprint(print.getStyle(), world, stepLocation, print.getRotation(), print.getScale(),
						print.isRightFoot());
			}
		}
		return result;
	}

	/**
	 * Play special sounds that must stop the usual footstep figuring things out
	 * process.
	 */
	protected boolean playSpecialStoppingConditions(@Nonnull final LivingEntity entity) {
		if (entity.func_70090_H()) {
			if (proceedWithStep(entity)) {
				final FluidState fs = entity.func_130014_f_().func_204610_c(new BlockPos(entity.func_174824_e(1F)));
				final AcousticEvent evt = fs.func_206888_e() ? Constants.WALK : Constants.SWIM;
				FootstepLibrary.getSwimAcoustic().playAt(entity.func_213303_ch(), evt);
			}
			return true;
		}

		return false;
	}

	/**
	 * Tells if footsteps can be played.
	 */
	protected boolean hasSpecialStoppingConditions(@Nonnull final LivingEntity entity) {
		return entity.func_70090_H();
	}

	@Nullable
	protected Association findAssociationMessyFoliage(@Nonnull final LivingEntity entity, @Nonnull final BlockPos pos) {
		Association result = null;
		final BlockPos up = pos.func_177984_a();
		final BlockState above = entity.func_130014_f_().func_180495_p(up);

		if (above.func_185904_a() != Material.field_151579_a) {
			IAcoustic acoustics = FootstepLibrary.getBlockAcoustics(above, Substrate.MESSY);
			if (acoustics == Constants.MESSY_GROUND) {
				acoustics = FootstepLibrary.getBlockAcoustics(above, Substrate.FOLIAGE);
				if (acoustics != Constants.NOT_EMITTER) {
					result = new Association(entity, acoustics);
				}
			}
		}
		return result;
	}

	/**
	 * Adds additional sound overlays to the acoustic based on other environment
	 * aspects, such as armor being worn.
	 */
	@Nullable
	protected Association addFootstepAccent(@Nonnull final LivingEntity entity, @Nullable Association assoc) {
		// Don't apply overlays if the entity is not on the ground
		if (entity.func_233570_aj_()) {
			accents.clear();
			final BlockPos pos = assoc != null ? assoc.getStepPos() : entity.func_233580_cy_();
			FootstepAccents.provide(entity, pos, accents);
			if (accents.size() > 0) {
				if (assoc == null) {
					final IAcoustic acoustic = AcousticCompiler.combine(accents);
					assoc = new Association(entity, acoustic);
				} else {
					assoc.merge(accents.toArray(new IAcoustic[0]));
				}
			}
		}

		return assoc;
	}

	@Override
	public String toString() {
		return "didJump: " + this.didJump + ' ' +
				"onLadder: " + this.isOnLadder + ' ' +
				"flying: " + this.isFlying + ' ' +
				"immobile: " + this.isImmobile + ' ' +
				"steps: " + this.pedometer;
	}

}