/*
 *  Dynamic Surroundings: Environs
 *  Copyright (C) 2019  OreCruncher
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>
 */

package dynamiclabs.immersivefx.environs.effects.particles;

import dynamiclabs.immersivefx.lib.GameUtils;
import net.minecraft.client.particle.IAnimatedSprite;
import net.minecraft.client.particle.IParticleRenderType;
import net.minecraft.client.particle.SpriteTexturedParticle;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import dynamiclabs.immersivefx.lib.random.XorShiftRandom;

import javax.annotation.Nonnull;
import java.util.Random;

@OnlyIn(Dist.CLIENT)
public class SteamCloudParticle extends SpriteTexturedParticle {

    private static final Random RANDOM = XorShiftRandom.current();

    private final IAnimatedSprite field_217583_C;

    public SteamCloudParticle(World world, double x, double y, double z, double dY) {
        super((ClientWorld) world, x, y, z, RANDOM.nextGaussian() * 0.02D, dY,
                RANDOM.nextGaussian() * 0.02D);

        this.field_217583_C = GameUtils.getMC().field_71452_i.field_215242_i.get(ParticleTypes.field_197613_f.getRegistryName());
        this.field_187129_i *= 0.1F;
        this.field_187130_j *= 0.1F;
        this.field_187131_k *= 0.1F;
        //this.motionX += motionX;
        this.field_187130_j += dY;
        //this.motionZ += motionZ;
        float f1 = 1.0F - (float) (Math.random() * (double) 0.3F);
        this.field_70552_h = f1;
        this.field_70553_i = f1;
        this.field_70551_j = f1;
        this.field_70544_f *= 1.875F;
        int i = (int) (8.0D / (Math.random() * 0.8D + 0.3D));
        this.field_70547_e = (int) Math.max((float) i * 2.5F, 1.0F);
        this.field_190017_n = false;
        this.func_217566_b(this.field_217583_C);
    }

    @Nonnull
    public IParticleRenderType func_217558_b() {
        return IParticleRenderType.field_217603_c;
    }

    public float func_217561_b(float p_217561_1_) {
        return this.field_70544_f * MathHelper.func_76131_a(((float) this.field_70546_d + p_217561_1_) / (float) this.field_70547_e * 32.0F, 0.0F, 1.0F);
    }

    public void func_189213_a() {
        this.field_187123_c = this.field_187126_f;
        this.field_187124_d = this.field_187127_g;
        this.field_187125_e = this.field_187128_h;
        if (this.field_70546_d++ >= this.field_70547_e) {
            this.func_187112_i();
        } else {
            this.func_217566_b(this.field_217583_C);
            this.func_187110_a(this.field_187129_i, this.field_187130_j, this.field_187131_k);
            this.field_187129_i *= 0.96F;
            this.field_187130_j *= 0.96F;
            this.field_187131_k *= 0.96F;

            if (this.field_187132_l) {
                this.field_187129_i *= 0.7F;
                this.field_187131_k *= 0.7F;
            }

        }
    }
}