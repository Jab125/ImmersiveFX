/*
 *  Dynamic Surroundings: Environs
 *  Copyright (C) 2019  OreCruncher
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>
 */

package dynamiclabs.immersivefx.environs.effects.particles;

import net.minecraft.block.BlockState;
import net.minecraft.client.particle.DiggingParticle;
import net.minecraft.client.world.ClientWorld;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import dynamiclabs.immersivefx.lib.WorldUtils;

import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

@OnlyIn(Dist.CLIENT)
public class DustParticle extends DiggingParticle {

	private final BlockPos.Mutable pos = new BlockPos.Mutable();

	public DustParticle(final World world, final double x, final double y, final double z, final BlockState state) {
		this(world, x, y, z, 0, 0, 0, state);
	}

	public DustParticle(final World world, final double x, final double y, final double z, final double dX, final double dY, final double dZ, final BlockState state) {
		super((ClientWorld) world, x, y, z, 0, 0, 0, state);

		this.field_190017_n = false;
		this.field_187129_i = dX;
		this.field_187130_j = dY;
		this.field_187131_k = dZ;

		func_70541_f((float) (0.3F + this.field_187136_p.nextGaussian() / 30.0F));
		func_187109_b(this.field_187126_f, this.field_187127_g, this.field_187128_h);
	}

	@Override
	public void func_187110_a(final double dX, final double dY, final double dZ) {
		this.field_187126_f += dX;
		this.field_187127_g += dY;
		this.field_187128_h += dZ;
	}

	@Override
	public void func_189213_a() {
		this.field_187123_c = this.field_187126_f;
		this.field_187124_d = this.field_187127_g;
		this.field_187125_e = this.field_187128_h;
		this.field_187130_j -= 0.04D * this.field_70545_g;
		func_187110_a(this.field_187129_i, this.field_187130_j, this.field_187131_k);
		this.field_187129_i *= 0.9800000190734863D;
		this.field_187130_j *= 0.9800000190734863D;
		this.field_187131_k *= 0.9800000190734863D;

		this.pos.func_189532_c(this.field_187126_f, this.field_187127_g, this.field_187128_h);

		if (this.field_70547_e-- <= 0) {
			func_187112_i();
		} else if (WorldUtils.isBlockSolid(this.field_187122_b, this.pos)) {
			func_187112_i();
		}
	}
}