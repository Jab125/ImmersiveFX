/*
 *  Dynamic Surroundings
 *  Copyright (C) 2020  OreCruncher
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>
 */

package dynamiclabs.immersivefx.environs.shaders.aurora;

import com.mojang.blaze3d.matrix.MatrixStack;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.IVertexBuilder;
import dynamiclabs.immersivefx.environs.shaders.ShaderPrograms;
import dynamiclabs.immersivefx.lib.GameUtils;
import dynamiclabs.immersivefx.lib.math.MathStuff;
import net.minecraft.client.renderer.*;
import net.minecraft.util.math.vector.Matrix4f;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.math.vector.Vector3f;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import dynamiclabs.immersivefx.lib.shaders.ShaderCallContext;

import javax.annotation.Nonnull;
import java.util.function.Consumer;

/*
 * Renders a shader generated aurora along a curved path.  Makes it ribbon like.
 */
@OnlyIn(Dist.CLIENT)
public class AuroraShaderBand extends AuroraBase {

	private static final float V1 = 0;
	private static final float V2 = 0.5F;
	
	protected ShaderPrograms program;
	protected Consumer<ShaderCallContext> callback;

	protected final float auroraWidth;
	protected final float panelTexWidth;
	
	public AuroraShaderBand(final long seed) {
		super(seed);

		this.program = ShaderPrograms.AURORA;

		this.callback = shaderCallContext -> {
			shaderCallContext.set("time", AuroraUtils.getTimeSeconds() * 0.75F);
			shaderCallContext.set("resolution", AuroraShaderBand.this.getAuroraWidth(), AuroraShaderBand.this.getAuroraHeight());
			shaderCallContext.set("topColor", AuroraShaderBand.this.getFadeColor());
			shaderCallContext.set("middleColor", AuroraShaderBand.this.getMiddleColor());
			shaderCallContext.set("bottomColor", AuroraShaderBand.this.getBaseColor());
			shaderCallContext.set("alpha", AuroraShaderBand.this.getAlpha());
		};

		this.auroraWidth = this.band.getPanelCount() * this.band.getNodeWidth();
		this.panelTexWidth = this.band.getNodeWidth() / this.auroraWidth;
	}

	@Override
	public void update() {
		super.update();
		this.band.update();
	}

	@Override
	protected float getAlpha() {
		return MathStuff.clamp((this.band.getAlphaLimit() / 255F) * this.tracker.ageRatio() * 2.0F, 0F, 1F);
	}

	protected float getAuroraWidth() {
		return this.auroraWidth;
	}

	protected float getAuroraHeight() {
		return AuroraBand.AURORA_AMPLITUDE;
	}

	protected void generateBand(@Nonnull final IVertexBuilder builder, @Nonnull final Matrix4f matrix) {

		for (int i = 0; ; i++) {
			final Vector3f[] quad = this.band.getPanelQuad(i);
			if (quad == null)
				break;

			final float u1 = i * this.panelTexWidth;
			final float u2 = u1 + this.panelTexWidth;

			builder.func_227888_a_(matrix, quad[0].func_195899_a(), quad[0].func_195900_b(), quad[0].func_195902_c()).func_225583_a_(u1, V1).func_181675_d();
			builder.func_227888_a_(matrix, quad[1].func_195899_a(), quad[1].func_195900_b(), quad[1].func_195902_c()).func_225583_a_(u2, V1).func_181675_d();
			builder.func_227888_a_(matrix, quad[2].func_195899_a(), quad[2].func_195900_b(), quad[2].func_195902_c()).func_225583_a_(u2, V2).func_181675_d();
			builder.func_227888_a_(matrix, quad[3].func_195899_a(), quad[3].func_195900_b(), quad[3].func_195902_c()).func_225583_a_(u1, V2).func_181675_d();
		}

	}

	@Override
	public void render(@Nonnull final MatrixStack matrixStack, final float partialTick) {

		if (this.program == null)
			return;

		this.band.translate(partialTick);

		final double tranY = getTranslationY(partialTick);
		final double tranX = getTranslationX(partialTick);
		final double tranZ = getTranslationZ(partialTick);

		final Vector3d view = GameUtils.getMC().field_71460_t.func_215316_n().func_216785_c();
		matrixStack.func_227860_a_();
		matrixStack.func_227861_a_(-view.func_82615_a(), -view.func_82617_b(), -view.func_82616_c());

		final RenderType type = AuroraRenderType.QUAD;
		final IRenderTypeBuffer.Impl buffer = GameUtils.getMC().func_228019_au_().func_228487_b_();

		ShaderPrograms.MANAGER.useShader(this.program, this.callback);

		try {

			for (int b = 0; b < this.bandCount; b++) {
				final IVertexBuilder builder = buffer.getBuffer(type);
				matrixStack.func_227860_a_();
				matrixStack.func_227861_a_(tranX, tranY, tranZ + this.offset * b);
				generateBand(builder, matrixStack.func_227866_c_().func_227870_a_());
				matrixStack.func_227865_b_();
				RenderSystem.disableDepthTest();
				buffer.func_228462_a_(type);
			}

		} catch (final Exception ex) {
			ex.printStackTrace();
			this.program = null;
		}

		ShaderPrograms.MANAGER.releaseShader();

		matrixStack.func_227865_b_();
	}

	@Override
	public String toString() {
		return "<SHADER> " + super.toString();
	}
}
