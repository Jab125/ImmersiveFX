/*
 *  Dynamic Surroundings
 *  Copyright (C) 2020  OreCruncher
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>
 */

package dynamiclabs.immersivefx.environs.library;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.Nonnull;

import com.google.gson.reflect.TypeToken;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.biome.BiomeRegistry;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import dynamiclabs.immersivefx.dsurround.DynamicSurroundings;
import dynamiclabs.immersivefx.environs.config.Config;
import dynamiclabs.immersivefx.environs.Environs;
import dynamiclabs.immersivefx.environs.library.config.BiomeConfig;
import dynamiclabs.immersivefx.lib.fml.ForgeUtils;
import dynamiclabs.immersivefx.lib.logging.IModLog;
import dynamiclabs.immersivefx.lib.math.MathStuff;

import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.biome.Biome;
import dynamiclabs.immersivefx.lib.resource.IResourceAccessor;
import dynamiclabs.immersivefx.lib.resource.ResourceUtils;
import dynamiclabs.immersivefx.lib.service.ModuleServiceManager;
import dynamiclabs.immersivefx.lib.service.IModuleService;
import dynamiclabs.immersivefx.lib.validation.ListValidator;
import dynamiclabs.immersivefx.lib.validation.Validators;

@OnlyIn(Dist.CLIENT)
public final class BiomeLibrary {

	private static final IModLog LOGGER = Environs.LOGGER.createChild(BiomeLibrary.class);

	private static final int INSIDE_Y_ADJUST = 3;

	public static final FakeBiomeAdapter UNDERGROUND = new FakeBiomeAdapter("Underground");
	public static final FakeBiomeAdapter PLAYER = new FakeBiomeAdapter("Player");
	public static final FakeBiomeAdapter UNDERWATER = new FakeBiomeAdapter("Underwater");
	public static final FakeBiomeAdapter UNDEROCEAN = new FakeBiomeAdapter("UnderOCN");
	public static final FakeBiomeAdapter UNDERDEEPOCEAN = new FakeBiomeAdapter("UnderDOCN");
	public static final FakeBiomeAdapter UNDERRIVER = new FakeBiomeAdapter("UnderRVR");
	public static final FakeBiomeAdapter OUTERSPACE = new FakeBiomeAdapter("OuterSpace");
	public static final FakeBiomeAdapter CLOUDS = new FakeBiomeAdapter("Clouds");
	public static final FakeBiomeAdapter VILLAGE = new FakeBiomeAdapter("Village");

	// This is for cases when the biome coming in doesn't make sense
	// and should default to something to avoid crap.
	private static final FakeBiomeAdapter WTF = new WTFFakeBiomeAdapter();

	public static final BiomeInfo UNDERGROUND_INFO = UNDERGROUND.getBiomeData();
	public static final BiomeInfo PLAYER_INFO = PLAYER.getBiomeData();
	public static final BiomeInfo UNDERRIVER_INFO = UNDERRIVER.getBiomeData();
	public static final BiomeInfo UNDEROCEAN_INFO = UNDEROCEAN.getBiomeData();
	public static final BiomeInfo UNDERDEEPOCEAN_INFO = UNDERDEEPOCEAN.getBiomeData();
	public static final BiomeInfo UNDERWATER_INFO = UNDERWATER.getBiomeData();
	public static final BiomeInfo OUTERSPACE_INFO = OUTERSPACE.getBiomeData();
	public static final BiomeInfo CLOUDS_INFO = CLOUDS.getBiomeData();
	public static final BiomeInfo VILLAGE_INFO = VILLAGE.getBiomeData();
	public static final BiomeInfo WTF_INFO = WTF.getBiomeData();

	private static final ObjectOpenHashSet<FakeBiomeAdapter> theFakes = new ObjectOpenHashSet<>();

	static {
		theFakes.add(UNDERGROUND);
		theFakes.add(PLAYER);
		theFakes.add(UNDERWATER);
		theFakes.add(UNDEROCEAN);
		theFakes.add(UNDERDEEPOCEAN);
		theFakes.add(UNDERRIVER);
		theFakes.add(OUTERSPACE);
		theFakes.add(CLOUDS);
		theFakes.add(VILLAGE);
		theFakes.add(WTF);
	}

	private BiomeLibrary() {

	}

	static void initialize() {
		ModuleServiceManager.instance().add(new BiomeLibraryService());
	}

	static void initFromConfig(@Nonnull final List<BiomeConfig> cfg) {

		if (cfg.size() > 0) {
			final BiomeEvaluator evaluator = new BiomeEvaluator();
			for (final BiomeInfo bi : getCombinedStream()) {
				evaluator.update(bi);
				for (final BiomeConfig c : cfg) {
					if (evaluator.matches(c.conditions)) {
						try {
							bi.update(c);
						} catch (@Nonnull final Throwable t) {
							LOGGER.warn("Unable to process biome sound configuration [%s]", c.toString());
						}
					}
				}
			}
		}
	}

	@Nonnull
	public static BiomeInfo getPlayerBiome(@Nonnull final PlayerEntity player, final boolean getTrue) {
		final Biome biome = player.func_130014_f_().func_226691_t_(new BlockPos(player.func_226277_ct_(), 0, player.func_226281_cx_()));
		BiomeInfo info = BiomeUtil.getBiomeData(biome);

		if (!getTrue) {
			if (player.func_208600_a(FluidTags.field_206959_a)) {
				if (info.isRiver())
					info = UNDERRIVER_INFO;
				else if (info.isDeepOcean())
					info = UNDERDEEPOCEAN_INFO;
				else if (info.isOcean())
					info = UNDEROCEAN_INFO;
				else
					info = UNDERWATER_INFO;
			} else {
				final DimensionInfo dimInfo = DimensionLibrary.getData(player.func_130014_f_());
				final int theY = MathStuff.floor(player.func_226278_cu_());
				if ((theY + INSIDE_Y_ADJUST) <= dimInfo.getSeaLevel())
					info = UNDERGROUND_INFO;
				else if (theY >= dimInfo.getSpaceHeight())
					info = OUTERSPACE_INFO;
				else if (theY >= dimInfo.getCloudHeight())
					info = CLOUDS_INFO;
			}
		}

		return info;
	}

	private static Collection<BiomeInfo> getCombinedStream() {
		return Stream.concat(
				ForgeUtils.getBiomes().stream().map(BiomeUtil::getBiomeData),
				theFakes.stream().map(FakeBiomeAdapter::getBiomeData)
		).collect(Collectors.toCollection(ArrayList::new));
	}

	static class BiomeLibraryService implements IModuleService {

		private static final Type biomeType = TypeToken.getParameterized(List.class, BiomeConfig.class).getType();

		static {
			Validators.registerValidator(biomeType, new ListValidator<BiomeConfig>());
		}

		@Override
		public String name() {
			return "BiomeLibrary";
		}

		@Override
		public void start() {

			ForgeUtils.getBiomes().forEach(b -> {
				final BiomeAdapter handler = new BiomeAdapter(b);
				BiomeUtil.setBiomeData(b, new BiomeInfo(handler));
			});

			// Make sure the default biomes are set
			BiomeUtil.getBiomeData(BiomeRegistry.field_244200_a);
			BiomeUtil.getBiomeData(BiomeRegistry.field_244201_b);

			final Collection<IResourceAccessor> configs = ResourceUtils.findConfigs(DynamicSurroundings.MOD_ID, DynamicSurroundings.DATA_PATH, "biomes.json");

			IResourceAccessor.process(configs, accessor -> initFromConfig(accessor.as(biomeType)));
		}

		@Override
		public void log() {
			if (Config.CLIENT.logging.enableLogging.get()) {
				LOGGER.info("*** BIOME REGISTRY ***");
				getCombinedStream().stream().sorted().map(Object::toString).forEach(LOGGER::info);
			}

			getCombinedStream().forEach(BiomeInfo::trim);
		}

		@Override
		public void stop() {
			ForgeUtils.getBiomes().forEach(b -> BiomeUtil.setBiomeData(b, null));
			BiomeUtil.setBiomeData(BiomeRegistry.field_244200_a, null);
			BiomeUtil.setBiomeData(BiomeRegistry.field_244201_b, null);
		}
	}

}
