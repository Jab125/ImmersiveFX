/*
 * Dynamic Surroundings
 * Copyright (C) 2020  OreCruncher
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>
 */

package dynamiclabs.immersivefx.environs;

import dynamiclabs.immersivefx.dsurround.DynamicSurroundings;
import dynamiclabs.immersivefx.environs.handlers.Manager;
import dynamiclabs.immersivefx.environs.library.Constants;
import dynamiclabs.immersivefx.environs.library.Libraries;
import dynamiclabs.immersivefx.environs.shaders.ShaderPrograms;
import dynamiclabs.immersivefx.lib.logging.ModLog;
import dynamiclabs.immersivefx.sndctrl.api.IMC;
import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.IParticleFactory;
import net.minecraft.particles.BasicParticleType;
import net.minecraft.particles.ParticleTypes;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ExtensionPoint;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.InterModEnqueueEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLEnvironment;
import net.minecraftforge.fml.network.FMLNetworkConstants;
import org.apache.commons.lang3.tuple.Pair;
import dynamiclabs.immersivefx.environs.config.Config;

import javax.annotation.Nonnull;

@Mod(Environs.MOD_ID)
public final class Environs {

    /**
     * ID of the mod
     */
    public static final String MOD_ID = "environs";
    /**
     * Logging instance for trace
     */
    public static final ModLog LOGGER = new ModLog(Environs.class);

    public Environs() {

        // Since we are 100% client side
        ModLoadingContext.get().registerExtensionPoint(ExtensionPoint.DISPLAYTEST, () -> Pair.of(() -> FMLNetworkConstants.IGNORESERVERONLY, (a, b) -> true));

        if (FMLEnvironment.dist == Dist.CLIENT) {
            // Various event bus registrations
            FMLJavaModLoadingContext.get().getModEventBus().addListener(this::clientSetup);
            FMLJavaModLoadingContext.get().getModEventBus().addListener(this::enqueueIMC);
            MinecraftForge.EVENT_BUS.register(this);

            // Initialize our configuration
            Config.setup();

            ShaderPrograms.MANAGER.initShaders();

            DynamicSurroundings.doConfigMenuSetup();
        }
    }

    private void clientSetup(@Nonnull final FMLClientSetupEvent event) {
        // Disable Particles if configured to do so
        if (Config.CLIENT.effects.disableUnderwaterParticles.get())
            Minecraft.func_71410_x().field_71452_i.func_199283_a(ParticleTypes.field_197605_P, (IParticleFactory<BasicParticleType>) null);
    }

    private void enqueueIMC(final InterModEnqueueEvent event) {
        IMC.registerSoundCategory(Constants.BIOMES);
        IMC.registerSoundCategory(Constants.SPOT_SOUNDS);
        IMC.registerSoundCategory(Constants.WATERFALL);

        IMC.registerCompletionCallback(Libraries::initialize);
        IMC.registerCompletionCallback(Libraries::complete);
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void clientConnect(@Nonnull final ClientPlayerNetworkEvent.LoggedInEvent event) {
        Manager.connect();
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void clientDisconnect(@Nonnull final ClientPlayerNetworkEvent.LoggedOutEvent event) {
        Manager.disconnect();
    }

}
