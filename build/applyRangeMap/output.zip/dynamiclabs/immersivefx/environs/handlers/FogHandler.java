/*
 *  Dynamic Surroundings
 *  Copyright (C) 2020  OreCruncher
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>
 */

package dynamiclabs.immersivefx.environs.handlers;

import com.mojang.blaze3d.platform.GlStateManager;
import dynamiclabs.immersivefx.environs.fog.*;
import dynamiclabs.immersivefx.lib.GameUtils;
import dynamiclabs.immersivefx.lib.math.LoggingTimerEMA;
import net.minecraft.client.renderer.FogRenderer;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.profiler.IProfiler;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import dynamiclabs.immersivefx.environs.config.Config;
import dynamiclabs.immersivefx.environs.fog.*;
import dynamiclabs.immersivefx.lib.events.DiagnosticEvent;

import javax.annotation.Nonnull;

@OnlyIn(Dist.CLIENT)
public class FogHandler extends HandlerBase {

    protected final LoggingTimerEMA render = new LoggingTimerEMA("Render Fog");

    protected HolisticFogRangeCalculator fogRange = new HolisticFogRangeCalculator();

    public FogHandler() {
        super("Fog Handler");
    }

    public static boolean doFog() {
        return Config.CLIENT.fog.enableFog.get() && CommonState.getDimensionInfo().hasFog();
    }

    @Override
    public void process(@Nonnull final PlayerEntity player) {
        if (doFog()) {
            this.fogRange.tick();
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void fogRenderEvent(final EntityViewRenderEvent.RenderFogEvent event) {
        if (event.getType() == FogRenderer.FogType.FOG_TERRAIN && doFog()) {
            final IProfiler profiler = GameUtils.getMC().func_213239_aq();
            profiler.func_76320_a("Environs Fog Render");
            this.render.begin();
            final FluidState fluidState = event.getInfo().func_216771_k();
            if (fluidState.func_206888_e()) {
                final FogResult result = this.fogRange.calculate(event);
                GlStateManager.func_227671_b_(result.getStart());
                GlStateManager.func_227687_c_(result.getEnd());
            }
            this.render.end();
            profiler.func_76319_b();
        }
    }

    @SubscribeEvent
    public void diagnostics(final DiagnosticEvent event) {
        if (Config.CLIENT.logging.enableLogging.get()) {
            if (doFog()) {
                event.getLeft().add("Fog Range: " + this.fogRange.toString());
                event.addRenderTimer(this.render);
            } else
                event.getLeft().add("FOG: IGNORED");
        }
    }

    @Override
    public void onConnect() {
        this.fogRange = new HolisticFogRangeCalculator();
        this.fogRange.add(new BiomeFogRangeCalculator());
        this.fogRange.add(new HazeFogRangeCalculator());
        this.fogRange.add(new MorningFogRangeCalculator());
        this.fogRange.add(new BedrockFogRangeCalculator());
        this.fogRange.add(new WeatherFogRangeCalculator());

//			this.fogRange
//					.add(new FixedFogRangeCalculator(this.theme.getMinFogDistance(), this.theme.getMaxFogDistance()));

    }

}
